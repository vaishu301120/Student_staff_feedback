<?php include "header.php"; 
include "connection.php"; ?>
<link href="./assets/css/main.css" rel="stylesheet" />
<link href="./assets/css/util.css" rel="stylesheet" />

<div class="container-login100" style="background-image: url('images/bg-01.jpg');">
		<div class="wrap-login100 p-l-55 p-r-55 p-t-80 p-b-30">
			<form class="login100-form validate-form" method="post">
				<span class="login100-form-title p-b-37">
					Login OTP
				</span>
				
				<div class="wrap-input100 validate-input m-b-20" data-validate="Enter Email ID">
					<input class="input100" type="email" name="email" placeholder="Valid Email" required>
					<span class="focus-input100"></span>
				</div>
				
				<div class="wrap-input100 validate-input m-b-20" data-validate="Enter Enrollment">
					<input class="input100" type="text" name="enrollment" placeholder="Valid Enrollment" required>
					<span class="focus-input100"></span>
				</div>

				<div class="container-login100-form-btn">
					<button class="login100-form-btn" type="submit" name="otpsubmit">
						Send OTP
					</button>
				</div>

			</form>

			
		</div>
	</div>
	
<?php 

if(isset($_POST['otpsubmit'])){
$enroll = $_POST['enrollment'];

$email = $_POST['email'];

$today_date = date('y-m-d');

$permitted_chars = '0123456789abcdefghijklmnopqrstuvwxyzABCDEFGHIJKLMNOPQRSTUVWXYZ';
$otp = $today_date.substr(str_shuffle($permitted_chars), 0, 10);

$sql = "INSERT INTO `otp` (`Enrollment_no`, `Email`, `OTP`, `Date`) VALUES ('$enroll', '$email', '$otp','$today_date')";
		$is_success = $conn->query($sql);
		
$to = $email;
$subject = "OTP for login";
$body = "Your Enrollment_no is $enroll and OTP is $otp";
$headers = "From: malekarpratiksha311@gmail.com";

if(mail($to,$subject,$body,$headers)){
  echo "<script> window.location.href='student_login.php'; </script>";	
}	
}
include "footer.php"; ?>
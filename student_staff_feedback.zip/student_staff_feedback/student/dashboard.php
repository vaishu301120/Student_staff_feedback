<?php include "header.php";
include "connection.php"; 
include "sub_header.php";


if(!isset($_SESSION['student']))
{
	echo "<script>alert('Login First');
	window.location.href='student_login.php';</script>";
}
else
{
	$thestudent = $_SESSION['student'];
		
}

$sql = "SELECT * FROM student_details WHERE Enrollment_no=$thestudent";
	$query = mysqli_query($conn,$sql) or die(mysqli_error());

	while($row = mysqli_fetch_array($query))
	{
	$student_roll_no=$row['Roll_no'];
	$student_class_name=$row['Class_name'];
	$student_course=$row['Course'];
	$student_name=$row['Student_name'];
	$department = $row['Department'];
	}
	
?>
<style>
  .center {
	margin: auto;
    width: 100%;
    padding: 10px;
    text-align: center;
	}

	.center button{
		width: 200px;padding: 20px;
	}
	
	.center a {
		color: white;
		font-size:20px;
	}
	
</style>

<div class="container-fluid before-gradients">

<div class="row col-lg-12">
  <div class="center">
  <?php $sql = "SELECT * FROM subject_details WHERE Course='$student_course' and Class_name='$student_class_name'";
	$query = mysqli_query($conn,$sql) or die(mysqli_error());

	while($row = mysqli_fetch_array($query))
	{
	$student_subject_code=$row['Subject_code'];
	$student_subject_name=$row['Subject_name'];	
	$student_subject_teacher=$row['Subject_teacher'];
	echo "<td><button class='btn' style='background-color:#bd59d4;margin-right:15px;'><a href='student_feedback.php?&roll=$student_roll_no&enroll=$thestudent&stud_name=$student_name&class=$student_class_name&course=$student_course&subjectcode=$row[Subject_code]&subjectname=$row[Subject_name]&subjectteacher=$row[Subject_teacher]&dept=$department' target='_blank'>$student_subject_name</a></button></td>";
									
	} ?>
    
  </div>
</div>


</div>

<?php include "footer.php"; ?>
<?php include "header.php";
include "connection.php"; 
include "sub_header.php";

if(!isset($_SESSION['student']))
{
	echo "<script>alert('Login First');
	window.location.href='student_login.php';</script>";
}
else
{
	$thestudent = $_SESSION['student'];
		
}

	$roll = $_GET['roll'];
	$enroll = $_GET['enroll'];
	$subjectcode = $_GET['subjectcode'];
	$subjectname = $_GET['subjectname'];
	$subjectteacher = $_GET['subjectteacher'];
	$dept = $_GET['dept'];
	$stud_name = $_GET['stud_name'];
	$class = $_GET['class'];
	$course = $_GET['course'];
	$subjectcode = $_GET['subjectcode'];
	$subjectname = $_GET['subjectname'];
	$subjectteacher = $_GET['subjectteacher'];
	$dept = $_GET['dept'];

if(isset($_POST['submit'])){
$que1 = $_POST['que1'];	
$que2 = $_POST['que2'];	
$que3= $_POST['que3'];	
$que4 = $_POST['que4'];	
$que5 = $_POST['que5'];	
$que6 = $_POST['que6'];	
$que7 = $_POST['que7'];	
$que8 = $_POST['que8'];	
$que9 = $_POST['que9'];	
$que10 = $_POST['que10'];	
$total = $que1 + $que2 + $que3 + $que4 + $que5 + $que6 + $que7 + $que8 + $que9 + $que10;
$suggestion = $_POST['suggestion'];	
	
$sql = "INSERT INTO `student_feedback` 
(`Enrollment_no`, `Roll_no`, `Student_name`, `Course`, `Class_name`, `Department`, `Subject_code`, `Subject_name`, `Subject_teacher`, `que1`,`que2`, `que3`, `que4`, `que5`, `que6`, `que7`, `que8`, `que9`, `que10`,`Total`, `Suggestion`) 
VALUES 
($enroll, $roll, '$stud_name', '$course', '$class', '$dept', $subjectcode, '$subjectname', '$subjectteacher', $que1, $que2, $que3, $que4, $que5, $que6, $que7, $que8, $que9, $que10, $total, '$suggestion');";
		$is_success = $conn->query($sql);
		if($is_success){ ?>
			<script>alert("Feedback Registered Successfully");</script>
		<?php }
		else { ?>
			<script>alert("Record Not Inserted");</script>
		<?php }
		
		
}
?>


<div class="container" style="background-color: #4444;">
	<div class="jumbotron">
		<div class="card" style="text-align: center;"><h2>Feedback for Subject: <?php echo $subjectname; ?> (<?php echo $subjectteacher; ?>)</h2></div>
		<div style="height:20px;"></div>
		<div class="card" style="font-size: 20px;text-align: center;color: #24365f;font-weight: 500;">
			<div class="card-body">
				Rating Conversion :- &nbsp;&nbsp;&nbsp;&nbsp; 5: Excellent | 4: Very Good | 3: Good | 2: Average | 1: Poor
			</div>
		</div>
		<div style="height:20px;"></div>
		<div class="card">
			<div class="card-body">
				<form method="POST">
					<?php
						$sql = "SELECT * FROM questionaire WHERE status='on'";
						$query = mysqli_query($conn,$sql) or die(mysqli_error());
						while($row = mysqli_fetch_array($query))
							{ ?>
								<div style="padding:20px 0;"><?php echo $row['que1']; ?></div>
								<input type='radio' id="que1-a" name="que1" value="1" style="margin-right:10px;" required><label for="que1-a" style="margin-right:25px;">1</label>
								<input type='radio' id="que1-b" name="que1" value="2" style="margin-right:10px;"><label for="que1-b" style="margin-right:25px;">2</label>
								<input type='radio' id="que1-c" name="que1" value="3" style="margin-right:10px;"><label for="que1-c" style="margin-right:25px;">3</label>
								<input type='radio' id="que1-d" name="que1" value="4" style="margin-right:10px;"><label for="que1-d" style="margin-right:25px;">4</label>
								<input type='radio' id="que1-e" name="que1" value="5" style="margin-right:10px;"><label for="que1-e" style="margin-right:25px;">5</label>
								<hr>
								
								<div style="padding:20px 0;"><?php echo $row['que2']; ?></div>
								<input type='radio' id="que2-a" name="que2" value="1" style="margin-right:10px;" required><label for="que2-a" style="margin-right:25px;">1</label>
								<input type='radio' id="que2-b" name="que2" value="2" style="margin-right:10px;"><label for="que2-b" style="margin-right:25px;">2</label>
								<input type='radio' id="que2-c" name="que2" value="3" style="margin-right:10px;"><label for="que2-c" style="margin-right:25px;">3</label>
								<input type='radio' id="que2-d" name="que2" value="4" style="margin-right:10px;"><label for="que2-d" style="margin-right:25px;">4</label>
								<input type='radio' id="que2-e" name="que2" value="5" style="margin-right:10px;"><label for="que2-e" style="margin-right:25px;">5</label>
								<hr>
					  
					  
								<div style="padding:20px 0;"><?php echo $row['que3']; ?></div>
								<input type='radio' id="que3-a" name="que3" value="1" style="margin-right:10px;" required><label for="que3-a" style="margin-right:25px;">1</label>
								<input type='radio' id="que3-b" name="que3" value="2" style="margin-right:10px;"><label for="que3-b" style="margin-right:25px;">2</label>
								<input type='radio' id="que3-c" name="que3" value="3" style="margin-right:10px;"><label for="que3-c" style="margin-right:25px;">3</label>
								<input type='radio' id="que3-d" name="que3" value="4" style="margin-right:10px;"><label for="que3-d" style="margin-right:25px;">4</label>
								<input type='radio' id="que3-e" name="que3" value="5" style="margin-right:10px;"><label for="que3-e" style="margin-right:25px;">5</label>
								<hr>
								
								<div style="padding:20px 0;"><?php echo $row['que4']; ?></div>
								<input type='radio' id="que4-a" name="que4" value="1" style="margin-right:10px;" required><label for="que4-a" style="margin-right:25px;">1</label>
								<input type='radio' id="que4-b" name="que4" value="2" style="margin-right:10px;"><label for="que4-b" style="margin-right:25px;">2</label>
								<input type='radio' id="que4-c" name="que4" value="3" style="margin-right:10px;"><label for="que4-c" style="margin-right:25px;">3</label>
								<input type='radio' id="que4-d" name="que4" value="4" style="margin-right:10px;"><label for="que4-d" style="margin-right:25px;">4</label>
								<input type='radio' id="que4-e" name="que4" value="5" style="margin-right:10px;"><label for="que4-e" style="margin-right:25px;">5</label>
								<hr>
								
								
								
								<div style="padding:20px 0;"><?php echo $row['que5']; ?></div>
								<input type='radio' id="que5-a" name="que5" value="1" style="margin-right:10px;" required><label for="que5-a" style="margin-right:25px;">1</label>
								<input type='radio' id="que5-b" name="que5" value="2" style="margin-right:10px;"><label for="que5-b" style="margin-right:25px;">2</label>
								<input type='radio' id="que5-c" name="que5" value="3" style="margin-right:10px;"><label for="que5-c" style="margin-right:25px;">3</label>
								<input type='radio' id="que5-d" name="que5" value="4" style="margin-right:10px;"><label for="que5-d" style="margin-right:25px;">4</label>
								<input type='radio' id="que5-e" name="que5" value="5" style="margin-right:10px;"><label for="que5-e" style="margin-right:25px;">5</label>
								<hr>
								
								<div style="padding:20px 0;"><?php echo $row['que6']; ?></div>
								<input type='radio' id="que6-a" name="que6" value="1" style="margin-right:10px;" required><label for="que6-a" style="margin-right:25px;">1</label>
								<input type='radio' id="que6-b" name="que6" value="2" style="margin-right:10px;"><label for="que6-b" style="margin-right:25px;">2</label>
								<input type='radio' id="que6-c" name="que6" value="3" style="margin-right:10px;"><label for="que6-c" style="margin-right:25px;">3</label>
								<input type='radio' id="que6-d" name="que6" value="4" style="margin-right:10px;"><label for="que6-d" style="margin-right:25px;">4</label>
								<input type='radio' id="que6-e" name="que6" value="5" style="margin-right:10px;"><label for="que6-e" style="margin-right:25px;">5</label>
								<hr>
								
								
								
								<div style="padding:20px 0;"><?php echo $row['que7']; ?></div>
								<input type='radio' id="que7-a" name="que7" value="1" style="margin-right:10px;" required><label for="que7-a" style="margin-right:25px;">1</label>
								<input type='radio' id="que7-b" name="que7" value="2" style="margin-right:10px;"><label for="que7-b" style="margin-right:25px;">2</label>
								<input type='radio' id="que7-c" name="que7" value="3" style="margin-right:10px;"><label for="que7-c" style="margin-right:25px;">3</label>
								<input type='radio' id="que7-d" name="que7" value="4" style="margin-right:10px;"><label for="que7-d" style="margin-right:25px;">4</label>
								<input type='radio' id="que7-e" name="que7" value="5" style="margin-right:10px;"><label for="que7-e" style="margin-right:25px;">5</label>
								<hr>
								
								<div style="padding:20px 0;"><?php echo $row['que8']; ?></div>
								<input type='radio' id="que8-a" name="que8" value="1" style="margin-right:10px;" required><label for="que8-a" style="margin-right:25px;">1</label>
								<input type='radio' id="que8-b" name="que8" value="2" style="margin-right:10px;"><label for="que8-b" style="margin-right:25px;">2</label>
								<input type='radio' id="que8-c" name="que8" value="3" style="margin-right:10px;"><label for="que8-c" style="margin-right:25px;">3</label>
								<input type='radio' id="que8-d" name="que8" value="4" style="margin-right:10px;"><label for="que8-d" style="margin-right:25px;">4</label>
								<input type='radio' id="que8-e" name="que8" value="5" style="margin-right:10px;"><label for="que8-e" style="margin-right:25px;">5</label>
								<hr>
								
								
								
								<div style="padding:20px 0;"><?php echo $row['que9']; ?></div>
								<input type='radio' id="que9-a" name="que9" value="1" style="margin-right:10px;" required><label for="que9-a" style="margin-right:25px;">1</label>
								<input type='radio' id="que9-b" name="que9" value="2" style="margin-right:10px;"><label for="que9-b" style="margin-right:25px;">2</label>
								<input type='radio' id="que9-c" name="que9" value="3" style="margin-right:10px;"><label for="que9-c" style="margin-right:25px;">3</label>
								<input type='radio' id="que9-d" name="que9" value="4" style="margin-right:10px;"><label for="que9-d" style="margin-right:25px;">4</label>
								<input type='radio' id="que9-e" name="que9" value="5" style="margin-right:10px;"><label for="que9-e" style="margin-right:25px;">5</label>
								<hr>
								
								<div style="padding:20px 0;"><?php echo $row['que10']; ?></div>
								<input type='radio' id="que10-a" name="que10" value="1" style="margin-right:10px;" required><label for="que10-a" style="margin-right:25px;">1</label>
								<input type='radio' id="que10-b" name="que10" value="2" style="margin-right:10px;"><label for="que10-b" style="margin-right:25px;">2</label>
								<input type='radio' id="que10-c" name="que10" value="3" style="margin-right:10px;"><label for="que10-c" style="margin-right:25px;">3</label>
								<input type='radio' id="que10-d" name="que10" value="4" style="margin-right:10px;"><label for="que10-d" style="margin-right:25px;">4</label>
								<input type='radio' id="que10-e" name="que10" value="5" style="margin-right:10px;"><label for="que10-e" style="margin-right:25px;">5</label>
								<hr>
								
								
								Any Suggestions<input type="text" name="suggestion" class="form-control"><br>
					  <?php } ?>
								<input type="submit" name="submit" value="Submit Feedback">
								
				</form>
				
				</div>
				</div>
				</div>
				</div>
					  
<?php include "footer.php"; ?>
<?php include "header.php"; 
include "connection.php"; ?>
<link href="./assets/css/main.css" rel="stylesheet" />
<link href="./assets/css/util.css" rel="stylesheet" />

<div class="container-login100" style="background-image: url('images/bg-01.jpg');">
		<div class="wrap-login100 p-l-55 p-r-55 p-t-80 p-b-30">
			<form class="login100-form validate-form" method="post">
				<span class="login100-form-title p-b-37">
					Student Login
				</span>

				<div class="wrap-input100 validate-input m-b-20" data-validate="Enter ID">
					<input class="input100" type="text" name="roll" placeholder="Roll No" required>
					<span class="focus-input100"></span>
				</div>
				
				<div class="wrap-input100 validate-input m-b-20" data-validate="Enter ID">
					<input class="input100" type="text" name="enrollment" placeholder="Enrollment No" required>
					<span class="focus-input100"></span>
				</div>

				<div class="wrap-input100 validate-input m-b-25" data-validate = "Enter password">
					<input class="input100" type="password" name="password" placeholder="Password" required>
					<span class="focus-input100"></span>
				</div>

				<div class="container-login100-form-btn">
					<button class="login100-form-btn" type="submit" name="login">
						Login
					</button>
				</div>

			</form>

			
		</div>
	</div>
	
<?php 
if(isset($_POST['login']))
{
	$roll=$_POST['roll'];
	$password=$_POST['password'];	
	$enrollment = $_POST['enrollment'];
	
	$sql = "SELECT Roll_no,Password,Enrollment_no FROM student_details WHERE Roll_no=$roll AND Enrollment_no=$enrollment AND Password='$password'";
	$query = mysqli_query($conn,$sql) or die(mysqli_error());

	while($row = mysqli_fetch_array($query))
	{
	$roll_no=$row['Roll_no'];
	$pwd=$row['Password'];	
	$enroll=$row['Enrollment_no'];
	}
	
	if($roll_no==$roll && $pwd==$password && $enrollment == $enroll)
	{
		$_SESSION['student']=$enroll;
		echo "<script> window.location.href='dashboard.php'; </script>";	
	}
	else
	{
		echo "<script> alert('Unsuccessful Login'); </script>";
		echo "<script> window.location.href='student_login.php' </script>";	
	}
}
include "footer.php"; ?>
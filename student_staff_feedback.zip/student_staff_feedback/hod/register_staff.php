<?php include "header.php";
include "connection.php";
include "sub_header.php";

if(!isset($_SESSION['hod']))
{
	echo "<script>alert('Login First');
	window.location.href='hod_login.php';</script>";
}
else
{
	$thehod = $_SESSION['hod'];
		
}

$sql = "SELECT Department FROM hod_details WHERE Prn_no=$thehod";
	$query = mysqli_query($conn,$sql) or die(mysqli_error());

	while($row = mysqli_fetch_array($query))
	{
	$staff_department=$row['Department'];
	}

if(isset($_POST['submit'])){
	$prn_no = $_POST['prn_no'];
	$staff_name = $_POST['staff_name'];
	$department = $_POST['department'];
	
	$password = $staff_name.rand(0,9999);
	
	$sql = "INSERT INTO `staff_details` (`Prn_No`, `Name`, `Department`, `Password`) VALUES ('$prn_no', '$staff_name', '$department', '$password');";
		$is_success = $conn->query($sql);
		if($is_success){ ?>
			<script>
			  alert("Staff details Registered Successfully");
			</script>
		<?php }
		else { ?>
			<script>alert("Record Not Inserted");</script>
		<?php }
}
?>
<script>
	document.getElementById("staff").onsubmit = function() { location.reload(true); } 
	
function deletestaffrecord(id){
	var confirm_status = confirm("Do you want to Delete Record");
	if(confirm_status == true){
		xhr2 = new XMLHttpRequest();
		xhr2.open('GET','staffdeleterecord_ajax_call.php?id=' + id , false );
		xhr2.onload = function(){
			location.reload();
		}
		xhr2.send();
	}
}

</script>
<div class="container" style="background-color: #4444;">
	<div class="jumbotron">
		<div class="card" style="text-align: center;"><h2>Register Staff Of Department</h2></div>
		<div style="height:50px;"></div>
		<div class="card">
			<div class="card-body">
				<form method="POST" id="staff" style="font-size:18px;">
					Prn No<input type="number" name="prn_no" class="form-control" required><br>
					Name<input type="text" name="staff_name" class="form-control" required><br>
					Department<input type="text" name="department" value="<?php echo $staff_department; ?>" class="form-control" required><br>
					<input type="submit" name="submit" value="Submit">
				</form>
			</div>
		</div>
		<div style="height:50px;"></div>
		<div class="card" style="text-align: center;"><h2>Update Staff Details</h2></div>
			<div class="card">
				<div class="card-body" style="text-align:center;">
					<table class="table table-bordered">
						<tr>
							<th>Prn_No</th>
							<th>Name</th>
							<th>Department</th>
							<th>Action</th>
						</tr>
					 <?php $sql = "SELECT Prn_no,Name,Department FROM staff_details where Department='$staff_department'";
						  $query = mysqli_query($conn,$sql) or die(mysqli_error());			
						  while($row = mysqli_fetch_array($query))
							{
									echo "<tr>";
									echo "<td>".$row['Prn_no']."</td>";
									echo "<td>".$row['Name']."</td>";
									echo "<td>".$row['Department']."</td>";
									echo "<td><a href='update_staff.php?prn=$row[Prn_no]&name=$row[Name]&dept=$row[Department]' class='btn btn-success' style='margin-right: 16px;padding: 5px 40px;'>Edit</a><button type='button' class='btn btn-warning' onclick='deletestaffrecord(".$row['Prn_no'].")' style='margin-right: 16px;padding: 5px 40px;'>Delete</button></td>";
									echo "</tr>";
							}
					 ?>
					</table>
	            </div>
			</div>



<?php include "footer.php" ?>
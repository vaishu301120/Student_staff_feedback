<?php include "header.php";
include "connection.php";
include "sub_header.php";
error_reporting(0);

if(!isset($_SESSION['hod']))
{
	echo "<script>alert('Login First');
	window.location.href='hod_login.php';</script>";
}
else
{
	$thehod = $_SESSION['hod'];
		
}

$sql = "SELECT Department FROM hod_details WHERE Prn_no=$thehod";
	$query = mysqli_query($conn,$sql) or die(mysqli_error());

	while($row = mysqli_fetch_array($query))
	{
	$hod_department=$row['Department'];	
	}
	
?>

<div class="container" style="background-color: #4444;">
	<div class="jumbotron">
		<div class="card" style="text-align: center;"><h2>WS/IV/GL Information</h2></div>
		<div style="height:50px;"></div>
		<div class="card">
			<div class="card-body">
				<form method="POST" style="font-size:18px;">
					Name Of Industry Person<input type="text" name="person" class="form-control" required><br>
					Subject<input type="text" name="subject" class="form-control" required><br>
					Topic<input type="text" name="topic" class="form-control" required><br> 
					Date<input type="date" name="lecture_date" class="form-control" required><br> 
					Duration<input type="text" name="lecture_duration" class="form-control" required><br> 
					
						<div style="margin:0 20px 17px 0">Courses:-</div>
							<?php $sql = "SELECT Distinct Course FROM class_details where Department = '$hod_department'";
								  $query = mysqli_query($conn,$sql) or die(mysqli_error());
									while($row = mysqli_fetch_array($query))
										{ ?>
											<?php echo $row['Course']; ?><input type="checkbox" name="course[]" value="<?php echo $row['Course']; ?>" style="margin-right:25px;margin-left:10px;">
										<?php } ?>
										
							<input type="submit" name="submit" value="Submit">

				</form>
			</div>
		</div>
						

<?php 

if(isset($_POST['submit'])){
	$person = $_POST['person'];
	$subject = $_POST['subject'];
	$topic = $_POST['topic'];
	$date = $_POST['lecture_date'];
	$duration = $_POST['lecture_duration'];
	$course = array();
	$course = $_POST['course'];
	$course_string = "";
	
	foreach($course as $courses){
		$course_string .= $courses;
		$course_string .= ",";
	} 
		$sql = "INSERT INTO `industry_lecture_details` (`Name`,`Subject`,`Topic`,`Date`,`Duration`,`Course`) VALUES ('$person','$subject','$topic','$date','$duration','$course_string');";
		$is_success = $conn->query($sql);	
		
		if($is_success){
			
			echo "<script>alert('Details Addded Successfully');</script>";
		}
}


include "footer.php" ?>
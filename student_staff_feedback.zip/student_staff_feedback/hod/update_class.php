<?php //session_start();
include "header.php";
include "connection.php";
include "sub_header.php";

if(!isset($_SESSION['hod']))
{
	echo "<script>alert('Login First');
	window.location.href='hod_login.php';</script>";
}
else
{
	$thehod = $_SESSION['hod'];
		
}

$class_name = $_GET['cn'];
$course = $_GET['course'];
$classteacher = $_GET['classteacher'];
$dept = $_GET['dept'];
?>
<div class="container" style="background-color: #4444;">
	<div class="jumbotron">
		<div class="card" style="text-align: center;"><h2>Edit Details for Class: <?php echo $class_name; ?></h2></div>
		<div style="height:50px;"></div>
		<div class="card">
			<div class="card-body">
				<form method="POST" id="class" style="font-size:18px;">
					Class Name<input type="text" name="update_class_name" value="<?php echo $class_name; ?>" class="form-control" required><br>
					Course<input type="text" name="update_course_name" value="<?php echo $course; ?>" class="form-control" required><br>
					Class Teacher<select name="update_class_teacher" id="class_teacher" class="form-control" required>
									<option value="<?php echo $classteacher; ?>"><?php echo $classteacher; ?></option>
										<?php $sql = "SELECT * FROM staff_details where Department = '$dept' and Name != '$classteacher'";
											  $query = mysqli_query($conn,$sql) or die(mysqli_error());
													while($row = mysqli_fetch_array($query)){ ?>
															<option value="<?php echo $row['Name'] ?>"><?php echo $row['Name'] ?></option>
										<?php } ?>
								</select><br>
					Department<input type="text" name="update_department" value="<?php echo $dept; ?>" class="form-control" readonly><br>
					<input type="submit" name="update" value="Update Details">
				</form>
			</div>
		</div>
	</div>
</div>

<?php
	if(isset($_POST['update'])){
	$update_class_name = $_POST['update_class_name'];
	$update_course_name = $_POST['update_course_name'];
	$update_class_teacher = $_POST['update_class_teacher'];
	$update_department = $_POST['update_department'];
	
	$sql1 = "UPDATE class_details SET Class_name='$update_class_name',Course='$update_course_name',Class_teacher='$update_class_teacher',Department='$update_department' where Class_name='$class_name'";
	$query1 = mysqli_query($conn,$sql1) or die(mysqli_error());
		if($query1){ ?>
			<script>
			  alert("Class updated Successfully");
			  window.location.href='register_class.php'; 
			</script>
		<?php }
		else { ?>
			<script>
				alert("Record Not Updated");
				window.location.href='update_class.php';
			</script>
		<?php }
}

include "footer.php"; ?>
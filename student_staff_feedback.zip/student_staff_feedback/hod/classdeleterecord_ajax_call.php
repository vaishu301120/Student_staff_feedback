<?php //session_start();
include "connection.php";

if(!isset($_SESSION['hod']))
{
	echo "<script>alert('Login First');
	window.location.href='hod_login.php';</script>";
}
else
{
	$thehod = $_SESSION['hod'];
		
} 

$id = $_GET['id'];
$sql = "Delete FROM class_details WHERE ID=$id";
	$query = mysqli_query($conn,$sql) or die(mysqli_error());
	
	if($query){ ?>
			<script>
			  alert("Class deleted Successfully");
			  window.location.href='register_class.php'; 
			</script>
		<?php }
		else { ?>
			<script>
				alert("Record Not Deleted");
			</script>
		<?php }

?>


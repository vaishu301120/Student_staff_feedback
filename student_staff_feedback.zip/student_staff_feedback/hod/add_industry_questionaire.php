<?php include "header.php";
include "connection.php";
include "sub_header.php";

error_reporting(0);

if(!isset($_SESSION['hod']))
{
	echo "<script>alert('Login First');
	window.location.href='hod_login.php';</script>";
}
else
{
	$thehod = $_SESSION['hod'];
	
}

/*$sql = "SELECT Department FROM hod_details WHERE Prn_no=$thehod";
	$query = mysqli_query($conn,$sql) or die(mysqli_error());

	while($row = mysqli_fetch_array($query))
	{
	$class_department=$row['Department'];
	}
*/
?>

<?php if(isset($_POST['submit'])){
	$que1 = $_POST['que1'];
	$que2 = $_POST['que2'];
	$que3 = $_POST['que3'];
	$que4 = $_POST['que4'];
	$que5 = $_POST['que5'];
	
	
	
	if($_POST['status'] == 'on'){
		$status = $_POST['status'];
	}else{
		$status = 'NA';
	}
	
	if($status == 'on'){
		$sql = "SELECT ID,Status FROM industry_questionaire WHERE Status='on'";
		$query = mysqli_query($conn,$sql) or die(mysqli_error());
		  while($row = mysqli_fetch_array($query)){
			  $ids = $row['ID'];
			  $sql1 = "UPDATE industry_questionaire SET Status='NA' where ID=$ids";
              $query1 = mysqli_query($conn,$sql1) or die(mysqli_error());
		  }
	}
	
	$sql = "INSERT INTO `industry_questionaire` (`que1`, `que2`, `que3`,`que4`, `que5`, `status`) VALUES ('$que1', '$que2', '$que3', '$que4', '$que5', '$status')";
		$is_success = $conn->query($sql);
		if($is_success){ ?>
			<script>
			  alert("Questionaire Added Successfully");
			</script>
		<?php }
		else { ?>
			<script>alert("Record Not Inserted");</script>
		<?php }
}
?>

<div class="container" style="background-color: #4444;">
	<div class="jumbotron">
		<div class="card" style="text-align: center;"><h2>Add Workshop/Guest Lecture Questionaire</h2></div>
		<div style="height:50px;"></div>
		<div class="card">
			<div class="card-body">
				<form method="POST" style="font-size:18px;">
					Question 1<input type="text" name="que1" class="form-control" required><br>
					Question 2<input type="text" name="que2" class="form-control" required><br>
					Question 3<input type="text" name="que3" class="form-control" required><br>
					Question 4<input type="text" name="que4" class="form-control" required><br>
					Question 5<input type="text" name="que5" class="form-control" required><br>
					<label style="margin-right:20px;">Do you want to active this questionaire?</label><input type="checkbox" name="status" value="on">
					<input type="submit" name="submit" value="Submit">
				</form>
			</div>
		</div>
	</div>
</div>

<?php include "footer.php"; ?>
<?php include "header.php";
include "connection.php";

if(!isset($_SESSION['hod']))
{
	echo "<script>alert('Login First');
	window.location.href='hod_login.php';</script>";
}
else
{
	$thehod = $_SESSION['hod'];
		
}

$selected_optionss = $_GET['class'];  ?>

<form method="post" style="margin-top: 100px;">
Select the Subject<select id="class_subject" onchange="myFunctionsss()">
					<option value="">Select Subject</option>
						<?php
							$sql = "SELECT Subject_name FROM subject_details where Class_name='$selected_optionss'";
							$query = mysqli_query($conn,$sql) or die(mysqli_error()); 
							while($row = mysqli_fetch_array($query)){ ?>
								<option value="<?php echo $row['Subject_name'];?>"><?php echo $row['Subject_name'];?></option>
							<?php } ?>
				</select>
</form>
<?php include "footer.php"; ?>
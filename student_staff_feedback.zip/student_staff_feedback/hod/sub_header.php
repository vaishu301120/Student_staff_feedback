<?php 
if(!isset($_SESSION['hod']))
{
	echo "<script>alert('Login First');
	window.location.href='hod_login.php';</script>";
}
else
{
	$thehod = $_SESSION['hod'];
		
}

$sql = "SELECT Name,Department FROM hod_details WHERE Prn_no=$thehod";
	$query = mysqli_query($conn,$sql) or die(mysqli_error());

	while($row = mysqli_fetch_array($query))
	{
	$sub_header_name=$row['Name'];
	$sub_header_department=$row['Department'];
	}
?>

<div class="container-fluid" style="background-color:#1aa5d8;min-height: 40px;">
	<div class="container">
		<div class="row" style="color: white;font-size: 16px;padding-top: 6px;">
			<div class="col-lg-3">Welcome <?php echo $sub_header_name; ?>,</div>
			<div class="col-lg-3">Designation :: HOD</div>
			<div class="col-lg-3">Department :: <?php echo $sub_header_department; ?></div>
			<div class="col-lg-3"><a href="logout.php" style="color:white;">Logout</a></div>
		</div>
	</div>
</div>
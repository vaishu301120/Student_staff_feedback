<?php //session_start();
include "connection.php";

if(!isset($_SESSION['hod']))
{
	echo "<script>alert('Login First');
	window.location.href='hod_login.php';</script>";
}
else
{
	$thehod = $_SESSION['hod'];
		
} 

$prn = $_GET['id'];
$sql = "Delete FROM staff_details WHERE Prn_no=$prn";
	$query = mysqli_query($conn,$sql) or die(mysqli_error());
	
	if($query){ ?>
			<script>
			  alert("Staff details deleted Successfully");
			  window.location.href='register_staff.php'; 
			</script>
		<?php }
		else { ?>
			<script>
				alert("Record Not Deleted");
			</script>
		<?php }

?>


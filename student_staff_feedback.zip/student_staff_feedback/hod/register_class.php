<?php include "header.php";
include "connection.php";
include "sub_header.php";

if(!isset($_SESSION['hod']))
{
	echo "<script>alert('Login First');
	window.location.href='hod_login.php';</script>";
}
else
{
	$thehod = $_SESSION['hod'];
		
}

$sql = "SELECT Department FROM hod_details WHERE Prn_no=$thehod";
	$query = mysqli_query($conn,$sql) or die(mysqli_error());

	while($row = mysqli_fetch_array($query))
	{
	$class_department=$row['Department'];
	}
?>
<script>
	document.getElementById("classs").onsubmit = function() { location.reload(true); } 
	
function deleteclassrecord(id){
	var confirm_status = confirm("Do you want to Delete Class");
	if(confirm_status == true){
		xhr2 = new XMLHttpRequest();
		xhr2.open('GET','classdeleterecord_ajax_call.php?id=' + id , false );
		xhr2.onload = function(){
			location.reload();
		}
		xhr2.send();
	}
}

</script>

<?php if(isset($_POST['submit'])){
	$class_name = $_POST['class_name'];
	$course_name = $_POST['course_name'];
	$class_teacher = $_POST['class_teacher'];
	$department = $_POST['department'];
	

	
	$sql = "INSERT INTO `class_details` (`Class_name`, `Course`, `Class_teacher`, `Department`) VALUES ('$class_name', '$course_name', '$class_teacher', '$department');";
		$is_success = $conn->query($sql);
		if($is_success){ ?>
			<script>
			  alert("Class Registered Successfully");
			</script>
		<?php }
		else { ?>
			<script>alert("Record Not Inserted");</script>
		<?php }
		
		
	//$sql1 = "UPDATE staff_details SET Is_classteacher='Yes',Classteacher_of_class_name='$class_name',Classteacher_of_course='$course_name' where Name='$class_teacher'";
	//$query1 = mysqli_query($conn,$sql1) or die(mysqli_error());

}
?>

<div class="container" style="background-color: #4444;">
	<div class="jumbotron">
		<div class="card" style="text-align: center;"><h2>Register Class</h2></div>
		<div style="height:50px;"></div>
		<div class="card">
			<div class="card-body">
				<form method="POST" id="classs" style="font-size:18px;">
					Class<input type="text" name="class_name" class="form-control" required><br>
					Course<input type="text" name="course_name" class="form-control" required><br>
					Class Teacher<select name="class_teacher" id="class_teacher" class="form-control" required>
									<option value="">Select Staff</option>
										<?php $sql = "SELECT * FROM staff_details where Department = '$class_department'";
											  $query = mysqli_query($conn,$sql) or die(mysqli_error());
													while($row = mysqli_fetch_array($query)){ ?>
															<option value="<?php echo $row['Name'] ?>"><?php echo $row['Name'] ?></option>
										<?php } ?>
								</select><br>
					Department<input type="text" name="department" value="<?php echo $class_department; ?>" class="form-control" required><br>
					<input type="submit" name="submit" value="Submit">
				</form>
			</div>
		</div>
		<div style="height:50px;"></div>
		<div class="card" style="text-align: center;"><h2>Update Class Details</h2></div>
			<div class="card">
				<div class="card-body" style="text-align:center;">
					<table class="table table-bordered">
						<tr>
							<th>Class Name</th>
							<th>Course</th>
							<th>Class Teacher</th>
							<th>Department</th>
							<th>Action</th>
						</tr>
					 <?php $sql = "SELECT * FROM class_details where Department='$class_department'";
						  $query = mysqli_query($conn,$sql) or die(mysqli_error());			
						  while($row = mysqli_fetch_array($query))
							{
									echo "<tr>";
									echo "<td>".$row['Class_name']."</td>";
									echo "<td>".$row['Course']."</td>";
									echo "<td>".$row['Class_teacher']."</td>";
									echo "<td>".$row['Department']."</td>";
									echo "<td><a href='update_class.php?cn=$row[Class_name]&course=$row[Course]&classteacher=$row[Class_teacher]&dept=$row[Department]' class='btn btn-success' style='margin-right: 16px;padding: 5px 40px;'>Edit</a><button type='button' class='btn btn-warning' onclick='deleteclassrecord(".$row['ID'].")' style='margin-right: 16px;padding: 5px 40px;'>Delete</button></td>";
									echo "</tr>";
							}
					 ?>
					</table>
	            </div>
			</div>



<?php include "footer.php" ?>
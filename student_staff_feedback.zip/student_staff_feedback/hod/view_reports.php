<?php include "header.php";
include "connection.php";
include "sub_header.php";

if(!isset($_SESSION['hod']))
{
	echo "<script>alert('Login First');
	window.location.href='hod_login.php';</script>";
}
else
{
	$thehod = $_SESSION['hod'];
		
}

$sql = "SELECT Department FROM hod_details WHERE Prn_no=$thehod";
	$query = mysqli_query($conn,$sql) or die(mysqli_error());

	while($row = mysqli_fetch_array($query))
	{
	$hod_department=$row['Department'];	
	}
	
?>

<div class="container" style="background-color: #4444;">
	<div class="jumbotron">
		<div class="card" style="text-align: center;"><h2>Class Wise Feedback</h2></div>
		<div style="height:50px;"></div>
		<div class="card">
			<div class="card-body">
				<form method="POST" id="staff" style="font-size:18px;">
					Department<input type="text" name="dept" id="dept" class="alternate-form-control" style="background-color: #e9ecef;opacity: 1;" value="<?php echo $hod_department; ?>" readonly>
					Select the Class<select id="class" class="alternate-form-control" onchange="myFunctions()">
						<option selected>Select class</option>
							<?php $sql = "SELECT Class_name FROM class_details where Department = '$hod_department'";
								  $query = mysqli_query($conn,$sql) or die(mysqli_error());
									while($row = mysqli_fetch_array($query))
										{ ?>
											<option value="<?php echo $row['Class_name']; ?>"><?php echo $row['Class_name']; ?></option>	
										<?php } ?>
										</select>
										
		Select the Subject<select id="outputs" class="alternate-form-control" onchange="myFunctionsss()"><option value="">Select Subject</option></select>
				</form>
			</div>
		</div>
		<div style="height:50px;"></div>
		<div class="card" style="text-align: center;"><h2>View Report</h2></div>
			<div class="card">
				<div class="card-body" id="outputsss" style="text-align:center;">
					<!-- output table will appear here -->
	            </div>
			</div>
<script>
function myFunctions(){
	//document.getElementById('output').innerHTML = '';
	var options_selected = document.getElementById("class").value;
	xhrs = new XMLHttpRequest();
	xhrs.open('GET','attend_hod_view_report_subject.php?class=' + options_selected );
	xhrs.onload = function(){
		document.getElementById('outputs').innerHTML = xhrs.responseText;
	}
	xhrs.send();
}


function myFunctionsss(){
	//document.getElementById('output').innerHTML = '';
	var dept = document.getElementById("dept").value;
	var options_selected = document.getElementById("class").value;
	var optionss_selected = document.getElementById("outputs").value;
	xhrsss = new XMLHttpRequest();
	xhrsss.open('GET','attend_hod_view_report_aggregate.php?department=' + dept + '&class=' + options_selected + '&subject=' + optionss_selected );
	xhrsss.onload = function(){
		document.getElementById('outputsss').innerHTML = xhrsss.responseText;
	}
	xhrsss.send();
}
</script>

<style>
.alternate-form-control{
	padding: .375rem .75rem;
    font-size: 1rem;
	color: #495057;
	border: 1px solid #ced4da;
	border-radius: .25rem;
	transition: border-color .15s ease-in-out,box-shadow .15s ease-in-out;
	margin: 0 40px 0 10px;
}
</style>
<?php 

if(isset($_POST['suggest'])){
	$department = $_POST['department'];
	$class = $_POST['class'];
	$subject = $_POST['subject'];
	$subject_teacher = $_POST['subject_teacher'];
	$message = $_POST['message'];
		$sql = "INSERT INTO `principal_hod_feedback` (`Department`,`Class`,`Subject`,`Teacher`,`Message`) VALUES ('$department','$class','$subject','$subject_teacher','$message');";
		$is_success = $conn->query($sql);	
}


include "footer.php" ?>
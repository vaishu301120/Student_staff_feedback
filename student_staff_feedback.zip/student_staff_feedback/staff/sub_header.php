<?php 
if(!isset($_SESSION['staff']))
{
	echo "<script>alert('Login First');
	window.location.href='staff_login.php';</script>";
}
else
{
	$thestaff = $_SESSION['staff'];
		
}

$sql = "SELECT Name,Department FROM staff_details WHERE Prn_no=$thestaff";
	$query = mysqli_query($conn,$sql) or die(mysqli_error());

	while($row = mysqli_fetch_array($query))
	{
	$sub_header_name=$row['Name'];
	$sub_header_department=$row['Department'];
	}
	
?>
<div class="container-fluid" style="background-color:#1aa5d8;min-height: 40px;">
	<div class="container">
		<div class="row" style="color: white;font-size: 16px;padding-top: 6px;">
			<div class="col-lg-3">Welcome <?php echo $sub_header_name; ?>,</div>
			<div class="col-lg-3">Designation :: Staff</div>
			<div class="col-lg-3">Department :: <?php echo $sub_header_department; ?></div>
			<div class="col-lg-1"><a href="logout.php" style="color:white;">Logout</a></div>
		</div>
	</div>
</div>
<?php include "header.php"; 
include "connection.php"; ?>

<link href="./assets/css/main.css" rel="stylesheet" />
<link href="./assets/css/util.css" rel="stylesheet" />

<div class="container-login100" style="background-image: url('images/bg-01.jpg');">
		<div class="wrap-login100 p-l-55 p-r-55 p-t-80 p-b-30">
			<form class="login100-form validate-form" method="post">
				<span class="login100-form-title p-b-37">
					Staff Login
				</span>

				<div class="wrap-input100 validate-input m-b-20" data-validate="Enter ID">
					<input class="input100" type="text" name="prn" placeholder="PRN" required>
					<span class="focus-input100"></span>
				</div>

				<div class="wrap-input100 validate-input m-b-25" data-validate = "Enter password">
					<input class="input100" type="password" name="password" placeholder="Password" required>
					<span class="focus-input100"></span>
				</div>

				<div class="container-login100-form-btn">
					<button class="login100-form-btn" type="submit" name="login">
						Login
					</button>
				</div>

			</form>

			
		</div>
	</div>
	
<?php 
if(isset($_POST['login']))
{
	$prn=$_POST['prn'];
	$password=$_POST['password'];	
	
	$sql = "SELECT Prn_no,Name,Password FROM staff_details WHERE Prn_no=$prn AND Password='$password'";
	$query = mysqli_query($conn,$sql) or die(mysqli_error());

	while($row = mysqli_fetch_array($query))
	{
	$prn_no=$row['Prn_no'];
	$pwd=$row['Password'];	
	$name=$row['Name'];
	}
	
	if($prn_no==$prn && $pwd==$password)
	{
		$_SESSION['staff']=$prn;
		echo "<script> window.location.href='dashboard.php'; </script>";	
	}
	else
	{
		echo "<script> alert('Unsuccessful Login'); </script>";
		echo "<script> window.location.href='staff_login.php' </script>";	
	}
}
include "footer.php"; ?>
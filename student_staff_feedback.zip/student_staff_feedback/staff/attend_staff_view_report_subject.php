<?php include "header.php";
include "connection.php";

if(!isset($_SESSION['staff']))
{
	echo "<script>alert('Login First');
	window.location.href='staff_login.php';</script>";
}
else
{
	$thestaff = $_SESSION['staff'];		
}

$department = $_GET['department']; 
$class = $_GET['class'];

$sql = "SELECT Name FROM staff_details WHERE Prn_no=$thestaff AND Department='$department'";
	$query = mysqli_query($conn,$sql) or die(mysqli_error());

	while($row = mysqli_fetch_array($query))
	{
	$staff_name=$row['Name'];	
	}

?>
<form method="post" style="margin-top: 100px;">
Select the Subject<select id="class_subject" onchange="myFunctionsss()">
					<option value="">Select Class</option>
						<?php
							$sql = "SELECT DISTINCT Subject_name FROM student_feedback WHERE Subject_teacher='$staff_name' AND Department='$department' AND Class_name='$class'";
							$query = mysqli_query($conn,$sql) or die(mysqli_error()); 
							while($row = mysqli_fetch_array($query)){ ?>
								<option value="<?php echo $row['Subject_name'];?>"><?php echo $row['Subject_name'];?></option>
							<?php } ?>
				</select>
</form>
<?php include "footer.php"; ?>
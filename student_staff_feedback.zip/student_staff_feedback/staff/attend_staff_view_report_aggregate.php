<?php include "connection.php";
session_start();
if(!isset($_SESSION['staff']))
{
	echo "<script>alert('Login First');
	window.location.href='staff_login.php';</script>";
}
else
{
	$thestaff = $_SESSION['staff'];
		
}

$department = $_GET['department'];
$class = $_GET['class']; 
$subject = $_GET['subject'];

$sql = "SELECT Name FROM staff_details WHERE Prn_no=$thestaff";
	$query = mysqli_query($conn,$sql) or die(mysqli_error());

	while($row = mysqli_fetch_array($query))
	{
	$subject_staff_name=$row['Name'];
	}


$aggregate = array();

	$sql = "SELECT Total FROM student_feedback WHERE Department='$department' AND Class_name='$class' AND Subject_name='$subject' AND Subject_teacher='$subject_staff_name'";
	$query = mysqli_query($conn,$sql) or die(mysqli_error());

	while($row = mysqli_fetch_array($query))
	{
		array_push($aggregate,$row['Total']);
	}
	
	?>
	
	<table class="table table-bordered">
		<tr style='background-color:lightblue;'>
			<th>Department</th>
			<th>Class</th>
			<th>Subject</th>
			<th>Subject Teacher</th>
			<th>No. of students gave feedback</th>
			<th>Feedback Aggregate</th>
		</tr>

		<?php
		echo "<tr style='background-color:white;'>";
		echo "<td>".$department."</td>";
		echo "<td>".$class."</td>";
		echo "<td>".$subject."</td>";
		echo "<td>".$subject_staff_name."</td>";
		echo "<td>".count($aggregate)."</td>";
		echo "<td>".array_sum($aggregate)/count($aggregate)."</td>";
		echo "</tr>";
		?>
</table>

<?php 


$sql = "SELECT Message FROM principal_hod_feedback WHERE Department='$department' AND Class='$class' AND Subject='$subject' AND Teacher='$subject_staff_name'";
	$query = mysqli_query($conn,$sql) or die(mysqli_error());

	while($row = mysqli_fetch_array($query))
		{ if(!empty($row['Message'])) { ?>
		<div class="right"><?php echo $row['Message']; ?> </div>
	<?php } }
	
	$sql = "SELECT Suggestion FROM student_feedback WHERE Department='$department' AND Class_name='$class' AND Subject_name='$subject' AND Subject_teacher='$subject_staff_name'";
	$query = mysqli_query($conn,$sql) or die(mysqli_error());

	while($row = mysqli_fetch_array($query))
	{ if(!empty($row['Suggestion'])) { ?>
		<div class="right"><?php echo $row['Suggestion']; ?> </div>
	<?php } } ?>
	
<style>
.right {
  position: relative;
  background: aqua;
  text-align: right;
  min-width: 45%;
  padding: 10px 15px;
  border-radius: 6px;
  border: 1px solid #ccc;
  float: right;
  right: 20px;
}

.right::before {
  content: '';
  position: absolute;
  visibility: visible;
  top: -1px;
  right: -10px;
  border: 10px solid transparent;
  border-top: 10px solid #ccc;
}

.right::after {
  content: '';
  position: absolute;
  visibility: visible;
  top: 0px;
  right: -8px;
  border: 10px solid transparent;
  border-top: 10px solid aqua;
  clear: both;
}
</style>
<?php include "footer.php";
?>
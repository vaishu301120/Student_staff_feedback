<?php include "header.php";
include "connection.php";
include "sub_header.php";

if(!isset($_SESSION['staff']))
{
	echo "<script>alert('Login First');
	window.location.href='staff_login.php';</script>";
}
else
{
	$thestaff = $_SESSION['staff'];
		
}

$sql = "SELECT Name FROM staff_details WHERE Prn_no=$thestaff";
	$query = mysqli_query($conn,$sql) or die(mysqli_error());

	while($row = mysqli_fetch_array($query))
	{
	$staff_name=$row['Name'];
	}
	

/*$sql = "SELECT Department,Class_name,Subject_name,Suggestion FROM student_feedback WHERE Subject_teacher='$staff_name'";
	$query = mysqli_query($conn,$sql) or die(mysqli_error());

	while($row = mysqli_fetch_array($query))
	{
	$department=$row['Department'];
	$class_name=$row['Class_name'];
	$subject_name=$row['Subject_name'];
	$student_suggestion=$row['Suggestion'];
	}
*/		
?>

<div class="container" style="background-color: #4444;">
	<div class="jumbotron">
		<div class="card" style="text-align: center;"><h2>Subject Wise Feedback</h2></div>
		<div style="height:50px;"></div>
		<div class="card">
			<div class="card-body">
				<form method="POST" id="staff-form" style="font-size:18px;">
					Select Department<select id="dept" class="alternate-form-control" onchange="myFunctions()">
						<option selected>Select Department</option>
							<?php $sql = "SELECT DISTINCT Department FROM student_feedback where Subject_teacher='$staff_name'";
								  $query = mysqli_query($conn,$sql) or die(mysqli_error());
									while($row = mysqli_fetch_array($query))
										{ ?>
											<option value="<?php echo $row['Department']; ?>"><?php echo $row['Department']; ?></option>	
										<?php } ?>
										</select>
										
					Select Class<select id="outputs" class="alternate-form-control" onchange="myFunctionss()">
						<option selected>Select class</option>
							
								</select>

					Select Subject<select id="outputss" class="alternate-form-control" onchange="myFunctionsss()">
						<option selected>Select subject</option>
							
								</select>
					
										
				</form>
			</div>
		</div>
		<div style="height:50px;"></div>
		<div class="card" style="text-align: center;"><h2>View Report</h2></div>
			<div class="card">
				<div class="card-body" id="outputsss" style="text-align:center;">
					<!-- output table will appear here -->
	            </div>
			</div>
<script>

function myFunctions(){
	//document.getElementById('output').innerHTML = '';
	var dept = document.getElementById("dept").value;
	xhrs = new XMLHttpRequest();
	xhrs.open('GET','attend_staff_view_report_class.php?department=' + dept );
	xhrs.onload = function(){
		document.getElementById('outputs').innerHTML = xhrs.responseText;
	}
	xhrs.send();
}

function myFunctionss(){
	//document.getElementById('output').innerHTML = '';
	var dept = document.getElementById("dept").value;
	var classname = document.getElementById("outputs").value;
	xhrss = new XMLHttpRequest();
	xhrss.open('GET','attend_staff_view_report_subject.php?department=' + dept + '&class=' + classname );
	xhrss.onload = function(){
		document.getElementById('outputss').innerHTML = xhrss.responseText;
	}
	xhrss.send();
}

function myFunctionsss(){
	//document.getElementById('output').innerHTML = '';
	var dept = document.getElementById("dept").value;
	var classname = document.getElementById("outputs").value;
	var subject = document.getElementById("outputss").value;
	xhrsss = new XMLHttpRequest();
	xhrsss.open('GET','attend_staff_view_report_aggregate.php?department=' + dept + '&class=' + classname + '&subject=' + subject );
	xhrsss.onload = function(){
		document.getElementById('outputsss').innerHTML = xhrsss.responseText;
	}
	xhrsss.send();
}
</script>

<style>
.alternate-form-control{
	padding: .375rem .75rem;
    font-size: 1rem;
	color: #495057;
	border: 1px solid #ced4da;
	border-radius: .25rem;
	transition: border-color .15s ease-in-out,box-shadow .15s ease-in-out;
	margin: 0 30px 0 10px;
}
</style>
<?php include "footer.php" ?>
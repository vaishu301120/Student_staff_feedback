<?php include "header.php";
include "connection.php";

if(!isset($_SESSION['staff']))
{
	echo "<script>alert('Login First');
	window.location.href='staff_login.php';</script>";
}
else
{
	$thestaff = $_SESSION['staff'];		
}

$department = $_GET['department']; 

$sql = "SELECT Name FROM staff_details WHERE Prn_no=$thestaff AND Department='$department'";
	$query = mysqli_query($conn,$sql) or die(mysqli_error());

	while($row = mysqli_fetch_array($query))
	{
	$staff_name=$row['Name'];	
	}

?>
<form method="post" style="margin-top: 100px;">
Select the Class<select id="department_class" onchange="myFunctionss()">
					<option value="">Select Class</option>
						<?php
							$sql = "SELECT DISTINCT Class_name FROM student_feedback WHERE Subject_teacher='$staff_name' AND Department='$department'";
							$query = mysqli_query($conn,$sql) or die(mysqli_error()); 
							while($row = mysqli_fetch_array($query)){ ?>
								<option value="<?php echo $row['Class_name'];?>"><?php echo $row['Class_name'];?></option>
							<?php } ?>
				</select>
</form>
<?php include "footer.php"; ?>
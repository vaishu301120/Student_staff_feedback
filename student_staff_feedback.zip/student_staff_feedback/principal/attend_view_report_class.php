<?php include "header.php";
include "connection.php";

if(!isset($_SESSION['principal']))
{
	echo "<script>alert('Login First');
	window.location.href='principal_login.php';</script>";
}
else
{
	$theprincipal = $_SESSION['principal'];
		
}


$selected_options = $_GET['options']; ?>

<form method="post" style="margin-top: 100px;">
Select the Class<select id="department_class" onchange="myFunctionss()">
					<option value="">Select Class</option>
						<?php
							$sql = "SELECT Class_name FROM class_details where Department='$selected_options'";
							$query = mysqli_query($conn,$sql) or die(mysqli_error()); 
							while($row = mysqli_fetch_array($query)){ ?>
								<option value="<?php echo $row['Class_name'];?>"><?php echo $row['Class_name'];?></option>
							<?php } ?>
				</select>
</form>
<?php include "footer.php"; ?>
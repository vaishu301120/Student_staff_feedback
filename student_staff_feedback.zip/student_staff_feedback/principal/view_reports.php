<?php include "header.php";
include "connection.php";
include "sub_header.php";
error_reporting(0);

if(!isset($_SESSION['principal']))
{
	echo "<script>alert('Login First');
	window.location.href='principal_login.php';</script>";
}
else
{
	$theprincipal = $_SESSION['principal'];
		
}

?>

<div class="container" style="background-color: #4444;">
	<div class="jumbotron">
		<div class="card" style="text-align: center;"><h2>Department Wise Feedback</h2></div>
		<div style="height:50px;"></div>
		<div class="card">
			<div class="card-body">
				<form method="POST" id="staff" style="font-size:18px;">
					Select the Department<select id="department" class="alternate-form-control" onchange="myFunctions()">
						<option selected>Select category</option>
							<?php $sql = "SELECT DISTINCT Department FROM hod_details";
								  $query = mysqli_query($conn,$sql) or die(mysqli_error());
									while($row = mysqli_fetch_array($query))
										{ ?>
											<option value="<?php echo $row['Department']; ?>"><?php echo $row['Department']; ?></option>	
										<?php } ?>
										</select>
										
		Select the Class
		<select id="outputs" class="alternate-form-control" onchange="myFunctionss()">
		<option value="">Select Class</option>
		</select>
		
		
		Select the Subject
		<select id="outputss" class="alternate-form-control" onchange="myFunctionsss()">
		<option value="">Select Subject</option>
		</select>
				</form>
			</div>
		</div>
		<div style="height:50px;"></div>
		<div class="card" style="text-align: center;"><h2>View Report</h2></div>
			<div class="card">
				<div class="card-body" id="outputsss" style="text-align:center;">
					<!-- output table will appear here -->
	            </div>
			</div>
<script>
function myFunctions(){
	//document.getElementById('output').innerHTML = '';
	var options_selected = document.getElementById("department").value;
	xhrs = new XMLHttpRequest();
	xhrs.open('GET','attend_view_report_class.php?options=' + options_selected );
	xhrs.onload = function(){
		document.getElementById('outputs').innerHTML = xhrs.responseText;
	}
	xhrs.send();
}



function myFunctionss(){
	//document.getElementById('output').innerHTML = '';
	var optionss_selected = document.getElementById("outputs").value;
	xhrss = new XMLHttpRequest();
	xhrss.open('GET','attend_view_report_subject.php?optionss=' + optionss_selected );
	xhrss.onload = function(){
		document.getElementById('outputss').innerHTML = xhrss.responseText;
	}
	xhrss.send();
}



function myFunctionsss(){
	//document.getElementById('output').innerHTML = '';
	var options_selected = document.getElementById("department").value;
	var optionss_selected = document.getElementById("outputs").value;
	var optionsss_selected = document.getElementById("outputss").value;
	xhrsss = new XMLHttpRequest();
	xhrsss.open('GET','attend_view_report_aggregate.php?department=' + options_selected + '&class=' + optionss_selected + '&subject=' + optionsss_selected );
	xhrsss.onload = function(){
		document.getElementById('outputsss').innerHTML = xhrsss.responseText;
	}
	xhrsss.send();
}
</script>

<style>
.alternate-form-control{
	padding: .375rem .75rem;
    font-size: 1rem;
	color: #495057;
	border: 1px solid #ced4da;
	border-radius: .25rem;
	transition: border-color .15s ease-in-out,box-shadow .15s ease-in-out;
	margin: 0 10px 0 10px;
}
</style>

<?php 

if(isset($_POST['suggest'])){
	$department = $_POST['department'];
	$class = $_POST['class'];
	$subject = $_POST['subject'];
	$subject_teacher = $_POST['subject_teacher'];
	$message = $_POST['message'];
		$sql = "INSERT INTO `principal_hod_feedback` (`Department`,`Class`,`Subject`,`Teacher`,`Message`) VALUES ('$department','$class','$subject','$subject_teacher','$message');";
		$is_success = $conn->query($sql);	
}

include "footer.php" ?>
<?php include "header.php";
include "connection.php";
include "sub_header.php";

if(!isset($_SESSION['principal']))
{
	echo "<script>alert('Login First');
	window.location.href='principal_login.php';</script>";
}
else
{
	$theprincipal = $_SESSION['principal'];
		
}

?>
<script>
	document.getElementById("hod").onsubmit = function() { location.reload(true); } 
	
function deleterecord(id){
	var confirm_status = confirm("Do you want to Delete Record");
	if(confirm_status == true){
		xhr2 = new XMLHttpRequest();
		xhr2.open('GET','deleterecord_ajax_call.php?id=' + id , false );
		xhr2.onload = function(){
			location.reload();
		}
		xhr2.send();
	}
}

</script>
<div class="container" style="background-color: #4444;">
	<div class="jumbotron">
		<div class="card" style="text-align: center;"><h2>Register Head Of Department</h2></div>
		
			<!-- Modal -->
			
			<!--	<button type="button" class="btn btn-primary" data-toggle="modal" data-target="#exampleModal">
  Add HOD
</button>

<div class="modal fade" id="exampleModal" tabindex="-1" role="dialog" aria-labelledby="exampleModalLabel" aria-hidden="true">
  <div class="modal-dialog" role="document">
    <div class="modal-content">
      <div class="modal-header">
        <h5 class="modal-title" id="exampleModalLabel">Register HOD</h5>
        <button type="button" class="close" data-dismiss="modal" aria-label="Close">
          <span aria-hidden="true">&times;</span>
        </button>
      </div>
      <div class="modal-body">
			<div class="card">
			<div class="card-body"> -->
				<form method="POST" id="hod" style="font-size:18px;">
					Prn No<input type="number" name="prn_no" class="form-control" required><br>
					Name<input type="text" name="hod_name" class="form-control" required><br>
					Department<input type="text" name="department" class="form-control" required><br>
					<input type="submit" name="submit" value="Submit">
				</form>
				<?php
					if(isset($_POST['submit'])){
						$prn_no = $_POST['prn_no'];
						$hod_name = $_POST['hod_name'];
						$department = $_POST['department'];
	
						$password = $hod_name.rand(1,9999);
	
						$sql = "INSERT INTO `hod_details` (`Prn_No`, `Name`, `Department`, `Password`) VALUES ($prn_no, '$hod_name', '$department', '$password');";
						$is_success = $conn->query($sql);
							if($is_success){ ?>
								<script>
									alert("HOD details Registered Successfully");
								</script>
							<?php }
							else { ?>
								<script>alert("Record Not Inserted");</script>
							<?php }
					} ?>
		<!--	</div>
		</div>
      </div>
      <div class="modal-footer">
        <button type="button" class="btn btn-secondary" data-dismiss="modal">Close</button>
      </div> -->

<!--Model-->
		<div style="height:50px;"></div>
	
		<div class="card" style="text-align: center;"><h2>Update HOD Details</h2></div>
			<div class="card">
				<div class="card-body" style="text-align:center;">
					<table class="table table-bordered">
						<tr>
							<th>Prn_No</th>
							<th>Name</th>
							<th>Department</th>
							<th>Action</th>
						</tr>
					 <?php $sql = "SELECT Prn_no,Name,Department FROM hod_details";
						  $query = mysqli_query($conn,$sql) or die(mysqli_error());			
						  while($row = mysqli_fetch_array($query))
							{
									echo "<tr>";
									echo "<td>".$row['Prn_no']."</td>";
									echo "<td>".$row['Name']."</td>";
									echo "<td>".$row['Department']."</td>";
									echo "<td><a href='update_hod.php?prn=$row[Prn_no]&name=$row[Name]&dept=$row[Department]' class='btn btn-success' style='margin-right: 16px;padding: 5px 40px;'>Edit</a><button type='button' class='btn btn-warning' onclick='deleterecord(".$row['Prn_no'].")' style='margin-right: 16px;padding: 5px 40px;'>Delete</button></td>";
									echo "</tr>";
							}
					 ?>
					</table>
	            </div>
			</div>
    </div>
  </div>
</div>



<?php include "footer.php" ?>
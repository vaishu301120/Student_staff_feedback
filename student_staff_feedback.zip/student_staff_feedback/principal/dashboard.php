<?php include "header.php"; 
include "connection.php";
include "sub_header.php";

if(!isset($_SESSION['principal']))
{
	echo "<script>alert('Login First');
	window.location.href='principal_login.php';</script>";
}
else
{
	$theprincipal = $_SESSION['principal'];
		
}

?>
<style>
  .center {
	margin: auto;
    width: 100%;
    padding: 10px;
    text-align: center;
    }

	.center button{
		width: 200px;padding: 20px;
	}
	
	.center a {
		color: white;
		font-size:20px;
	}
	
</style>

<div class="container-fluid before-gradients">

<div class="row col-lg-12">
  <div class="center">
    <button class="btn" style="background-color:#bd59d4;"><a href="register_hod.php" target="_blank">Register HOD</a></button>
	<button class="btn" style="background-color:#bd59d4;"><a href="add_questionaire.php" target="_blank">Add Questionaire</a></button>
	<button class="btn" style="background-color:#bd59d4;"><a href="view_reports.php" target="_blank">View Reports</a></button>
  </div>
</div>


</div>

<?php include "footer.php"; ?>
<?php $host ="localhost";
$username= "root";
$pwd="";
$database = "movies";
global $conn;
$conn = new mysqli($host,$username,$pwd,$database);
if($conn->connect_error){  
	echo $conn->connect_error;
}
?>
<?php 
if(!isset($_SESSION['principal']))
{
	echo "<script>alert('Login First');
	window.location.href='principal_login.php';</script>";
}
else
{
	$theprincipal = $_SESSION['principal'];
		
}


?>
<div class="container-fluid" style="background-color:#1aa5d8;min-height: 40px;">
	<div class="container">
		<div class="row" style="color: white;font-size: 16px;padding-top: 6px;">
			<div class="col-lg-9">Welcome <?php echo $theprincipal; ?>,</div>
			<div class="col-lg-2"><a href="logout.php" style="color:white;">Logout</a></div>
		</div>
	</div>
</div>
<?php 
include "connection.php";

if(!isset($_SESSION['principal']))
{
	echo "<script>alert('Login First');
	window.location.href='principal_login.php';</script>";
}
else
{
	$theprincipal = $_SESSION['principal'];
		
}

$department = $_GET['department'];
$class = $_GET['class']; 
$subject = $_GET['subject'];

$aggregate = array();

	$sql = "SELECT Subject_teacher,Total FROM student_feedback WHERE Department='$department' AND Class_name='$class' AND Subject_Name='$subject'";
	$query = mysqli_query($conn,$sql) or die(mysqli_error());

	while($row = mysqli_fetch_array($query))
	{
		$subject_teacher=$row['Subject_teacher'];
		array_push($aggregate,$row['Total']);
	}
	
	?>
	
	<table class="table table-bordered">
		<tr style='background-color:lightblue;'>
			<th>Department</th>
			<th>Class</th>
			<th>Subject</th>
			<th>Subject Teacher</th>
			<th>No. of students gave feedback</th>
			<th>Feedback Aggregate</th>
		</tr>

		<?php
		echo "<tr style='background-color:white;'>";
		echo "<td>".$department."</td>";
		echo "<td>".$class."</td>";
		echo "<td>".$subject."</td>";
		echo "<td>".$subject_teacher."</td>";
		echo "<td>".count($aggregate)."</td>";
		echo "<td>".array_sum($aggregate)/count($aggregate)."</td>";
		echo "</tr>";
		?>
    </table>
	
	
	<button type="button" class="btn btn-primary" data-toggle="modal" data-target="#exampleModal">
		Give Suggestions
	</button>

<!-- Modal -->
<div class="modal fade" id="exampleModal" tabindex="-1" role="dialog" aria-labelledby="exampleModalLabel" aria-hidden="true">
  <div class="modal-dialog" role="document">
    <div class="modal-content">
      <div class="modal-header">
        <h5 class="modal-title" id="exampleModalLabel">Suggestions/Appreciation</h5>
        <button type="button" class="close" data-dismiss="modal" aria-label="Close">
          <span aria-hidden="true">&times;</span>
        </button>
      </div>
      <div class="modal-body">
        <form method="POST">
			<input type="text" name="department" value="<?php echo $department; ?>" readonly>
			<input type="text" name="class" value="<?php echo $class; ?>" readonly>
			<input type="text" name="subject" value="<?php echo $subject; ?>" readonly>
			<input type="text" name="subject_teacher" value="<?php echo $subject_teacher; ?>" readonly><br>
			<textarea name="message" cols="40" row="2" placeholder="Write Here" style="margin-top:20px;"></textarea>
			<input type="submit" name="suggest" value="Post Message" style="width: 40%;padding:7px;">
		</form>
      </div>
      <div class="modal-footer">
        <button type="button" class="btn btn-secondary" data-dismiss="modal">Close</button>
      </div>
    </div>
  </div>
</div>



<?php 
include "footer.php";
?>
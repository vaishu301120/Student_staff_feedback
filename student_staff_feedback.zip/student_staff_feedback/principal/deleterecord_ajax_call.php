<?php //session_start();
include "connection.php";

/*if(!isset($_SESSION['sname']))
{
	echo "<script>alert('Login First');
	window.location.href='user_login.php';</script>";
}
else
{
	$thename = $_SESSION['sname'];
		
} */

$prn = $_GET['id'];
$sql = "Delete FROM hod_details WHERE Prn_no=$prn";
	$query = mysqli_query($conn,$sql) or die(mysqli_error());
	
	if($query1){ ?>
			<script>
			  alert("HOD details deleted Successfully");
			  window.location.href='register_hod.php'; 
			</script>
		<?php }
		else { ?>
			<script>
				alert("Record Not Deleted");
				window.location.href='update_hod.php';
			</script>
		<?php }

?>


<!DOCTYPE html>
<html lang="en">
<?php  session_start(); ?>
	<head>
		<meta charset="utf-8" />
		<meta http-equiv="X-UA-Compatible" content="IE=edge,chrome=1" />
		<title>
			Student Feedback System
		</title>
		<meta content='width=device-width, initial-scale=1.0, maximum-scale=1.0, user-scalable=0, shrink-to-fit=no' name='viewport' />
		<!--     Fonts and icons     -->
		<link href="https://fonts.googleapis.com/css?family=Montserrat:400,700,200" rel="stylesheet" />
		<link href="https://maxcdn.bootstrapcdn.com/font-awesome/latest/css/font-awesome.min.css" rel="stylesheet">
		<!-- CSS Files -->
		<link href="./assets/css/bootstrap.min.css" rel="stylesheet" />
		<style>
			.before-gradients::before{
				background: rgba(255,255,255,.5);
				content: "";
				display: block;
				position: absolute;
				z-index: -1;
				width: 100%;
				height: 100%;
				top: 0;
				left: 0;
			}
			.before-gradients{
				background-image:url('./assets/img/college_building.jpeg');
				width: 100%;
				height: 88vh;
				display: flex;
				flex-wrap: wrap;
				justify-content: flex-end;
				align-items: center;
				background-repeat: no-repeat;
				background-size: cover;
				background-position: center;
				position: relative;
				z-index: 1;
			}
			.navbar{
				background-color:#24365f;padding: 15px 0;position: relative;display: flex;padding:0 0 5px 0;
			}
			.college-name{
				display: grid;width: 100%;text-align: center;
			}
			.logo img{
				border: none;margin: auto;margin-right: 15px;margin-top: 5px;float: left;height: 65px;width: 65px;
			}
			.index-role-box{
				width: 390px;
				background: #fff;
				border-radius: 10px;
				overflow: hidden;
				box-shadow: 0 3px 20px 0px rgb(0 0 0 / 10%);
				padding:22px 55px 10px;
				margin-top:-30px;
			}
			.index-role-box span{
				display: block;
				font-family: SourceSansPro-Bold;
				font-size: 30px;
				color: #4b2354;
				line-height: 1.2;
				text-align: center;
			}
			.index-role-box-elements{
				width:100%;display: flex;flex-wrap: wrap;justify-content: center;
			}
			.index-role-box-elements button{
				display: flex;
				justify-content: center;
				align-items: center;
				padding: 0 20px;
				min-width: 160px;
				height: 50px;
				background-color: #bd59d4;
				border-radius: 25px;
				font-family: SourceSansPro-SemiBold;
				font-size: 14px;
				color: #fff;
				line-height: 1.2;
				text-transform: uppercase;box-shadow:0 10px 30px 0px rgb(189 89 212 / 50%);border:none;margin-bottom: 30px;
			}
			.index-role-box-elements button a {
				color: white;
			}
			a{
				color:white;
			}
			a:hover{
				color:white;
			}
			input[type=submit] {
				width: 100%;
				background-color: #bd59d4;
				color: white;
				padding: 14px 20px;
				margin: 8px 0;
				border: none;
				border-radius: 4px;
				cursor: pointer;
			}
		</style>
	</head>
	
	<body>
	
		<nav class="navbar-header navbar navbar-dark navbar-expand-lg">
			<div class="container"> 
				<a class="navbar-brand site-title logo p-0" href="https://www.rajgad.org.in/"><img src="./assets/img/college_logo.png"></a> 
						<div class="college-name">
								<font size="3" color="white">Rajgad Dnyanpeeth's</font>
								<font size="5" color="white"><b>SHRI CHHATRAPATI SAMBHAJIRAJE POLYTECHNIC</b></font>
						</div>
			</div>
		</nav>
		
		
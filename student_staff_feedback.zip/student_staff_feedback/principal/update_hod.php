<?php //session_start();
include "header.php";
include "connection.php";
include "sub_header.php";

if(!isset($_SESSION['principal']))
{
	echo "<script>alert('Login First');
	window.location.href='principal_login.php';</script>";
}
else
{
	$theprincipal = $_SESSION['principal'];
		
}

$prn = $_GET['prn'];
$name = $_GET['name'];
$dept = $_GET['dept'];
?>
<div class="container" style="background-color: #4444;">
	<div class="jumbotron">
		<div class="card" style="text-align: center;"><h2>Edit Details for Prn_no: <?php echo $prn; ?></h2></div>
		<div style="height:50px;"></div>
		<div class="card">
			<div class="card-body">
				<form method="POST" id="hod" style="font-size:18px;">
					Prn No<input type="number" name="update_prn_no" value="<?php echo $prn; ?>" class="form-control" required><br>
					Name<input type="text" name="update_hod_name" value="<?php echo $name; ?>" class="form-control" required><br>
					Department<input type="text" name="update_department" value="<?php echo $dept; ?>" class="form-control" required><br>
					<input type="submit" name="update" value="Update Details">
				</form>
			</div>
		</div>
	</div>
</div>

<?php
	if(isset($_POST['update'])){
	$update_prn_no = $_POST['update_prn_no'];
	$update_hod_name = $_POST['update_hod_name'];
	$update_department = $_POST['update_department'];
	
	$sql1 = "UPDATE hod_details SET Prn_no=$update_prn_no,Name='$update_hod_name',Department='$update_department' where Prn_no=$prn";
	$query1 = mysqli_query($conn,$sql1) or die(mysqli_error());
		if($query1){ ?>
			<script>
			  alert("HOD details updated Successfully");
			  window.location.href='register_hod.php'; 
			</script>
		<?php }
		else { ?>
			<script>
				alert("Record Not Updated");
				window.location.href='update_hod.php';
			</script>
		<?php }
}

include "footer.php"; ?>
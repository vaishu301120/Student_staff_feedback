<?php include "header.php";
include "connection.php" ?>
<link href="./assets/css/main.css" rel="stylesheet" />
<link href="./assets/css/util.css" rel="stylesheet" />

<div class="container-login100" style="background-image: url('images/bg-01.jpg');">
		<div class="wrap-login100 p-l-55 p-r-55 p-t-80 p-b-30">
			<form class="login100-form validate-form" method="post">
				<span class="login100-form-title p-b-37">
					Principal Login
				</span>

				<div class="wrap-input100 validate-input m-b-20" data-validate="Enter ID">
					<input class="input100" type="text" name="username" placeholder="ID" required>
					<span class="focus-input100"></span>
				</div>

				<div class="wrap-input100 validate-input m-b-25" data-validate = "Enter password" required>
					<input class="input100" type="password" name="password" placeholder="Password">
					<span class="focus-input100"></span>
				</div>

				<div class="container-login100-form-btn">
					<button class="login100-form-btn" type="submit" name="login">
						Login
					</button>
				</div>

			</form>

			
		</div>
	</div>
	
<?php 
if(isset($_POST['login']))
{
	$username=$_POST['username'];
	$password=$_POST['password'];	
	
	$sql = "SELECT Username,Password FROM principal_details WHERE Username='$username' AND Password='$password'";
	$query = mysqli_query($conn,$sql) or die(mysqli_error());

	while($row = mysqli_fetch_array($query))
	{
	$uid=$row['Username'];
	$pwd=$row['Password'];	
	}
	if($uid==$username && $pwd==$password)
	{
		$_SESSION['principal']=$username;
		echo "<script> window.location.href='dashboard.php'; </script>";	
	}
	else
	{
		echo "<script> alert('Unsuccessful Login'); </script>";
		echo "<script> window.location.href='principal_login.php' </script>";	
	}
}
include "footer.php"; ?>
<?php include "header.php"; ?>

<div class="container-fluid before-gradients">
			<div class="index-role-box">
				<span>
					Staff Feedback System
				</span>
				<hr>
				<span style="padding-bottom:30px;">
					Select Your Role
				</span>
				
				<div class="index-role-box-elements">
					<button type="button">
						<a href="./principal/principal_login.php">Principal</a>
					</button>
					
					<button type="button">
						<a href="./hod/hod_login.php">HOD</a>
					</button>
					
					<button type="button">
						<a href="./class_teacher/classteacher_login.php">Class Teacher</a>
					</button>
					
					<button type="button">
						<a href="./staff/staff_login.php">Staff</a>
					</button>
					
					<button type="button">
						<a href="./student/student_login.php">Student</a>
					</button>
					
				</div>
			
			</div>
		
		</div>

<?php include "footer.php"; ?>


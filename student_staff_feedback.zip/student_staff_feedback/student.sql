-- phpMyAdmin SQL Dump
-- version 5.0.4
-- https://www.phpmyadmin.net/
--
-- Host: 127.0.0.1
-- Generation Time: Sep 27, 2022 at 05:14 PM
-- Server version: 10.4.17-MariaDB
-- PHP Version: 7.3.27

SET SQL_MODE = "NO_AUTO_VALUE_ON_ZERO";
START TRANSACTION;
SET time_zone = "+00:00";


/*!40101 SET @OLD_CHARACTER_SET_CLIENT=@@CHARACTER_SET_CLIENT */;
/*!40101 SET @OLD_CHARACTER_SET_RESULTS=@@CHARACTER_SET_RESULTS */;
/*!40101 SET @OLD_COLLATION_CONNECTION=@@COLLATION_CONNECTION */;
/*!40101 SET NAMES utf8mb4 */;

--
-- Database: `student_staff_feedback`
--

-- --------------------------------------------------------

--
-- Table structure for table `class_details`
--

CREATE TABLE `class_details` (
  `ID` int(9) NOT NULL,
  `Class_name` varchar(50) NOT NULL,
  `Course` varchar(50) NOT NULL,
  `Class_teacher` varchar(100) NOT NULL,
  `Department` varchar(50) NOT NULL
) ENGINE=InnoDB DEFAULT CHARSET=utf8mb4;

--
-- Dumping data for table `class_details`
--

INSERT INTO `class_details` (`ID`, `Class_name`, `Course`, `Class_teacher`, `Department`) VALUES
(36, 'FYCO', 'CO-1-I', 'Vandana R Nangare', 'Computer'),
(37, 'SYCO', 'CO-3-I', 'Abhijit A Salunkhe', 'Computer'),
(38, 'TYCO', 'CO-5-I', 'Priyanka S Kedge', 'Computer');

-- --------------------------------------------------------

--
-- Table structure for table `hod_details`
--

CREATE TABLE `hod_details` (
  `Prn_no` int(9) NOT NULL,
  `Name` varchar(200) NOT NULL,
  `Department` varchar(200) NOT NULL,
  `Password` varchar(50) NOT NULL
) ENGINE=InnoDB DEFAULT CHARSET=utf8mb4;

--
-- Dumping data for table `hod_details`
--

INSERT INTO `hod_details` (`Prn_no`, `Name`, `Department`, `Password`) VALUES
(3, 'Mahesh D.Dhere', 'mechinical', 'Mahesh D.Dhere7904'),
(4, 'Pranaiv D. Dhaigude', 'E&TC', 'Pranaiv D. Dhaigude4803'),
(2, 'Sagar D. Nigade', 'Civil ', 'Sagar D. Nigade4926'),
(1, 'Sonali B Shinde', 'Computer', 'sonali');

-- --------------------------------------------------------

--
-- Table structure for table `principal_details`
--

CREATE TABLE `principal_details` (
  `ID` int(9) NOT NULL,
  `Username` varchar(50) NOT NULL,
  `Password` varchar(50) NOT NULL,
  `Designation` varchar(50) NOT NULL
) ENGINE=InnoDB DEFAULT CHARSET=utf8mb4;

--
-- Dumping data for table `principal_details`
--

INSERT INTO `principal_details` (`ID`, `Username`, `Password`, `Designation`) VALUES
(1, 'Principal', 'p#1', 'Principal');

-- --------------------------------------------------------

--
-- Table structure for table `principal_hod_feedback`
--

CREATE TABLE `principal_hod_feedback` (
  `ID` int(9) NOT NULL,
  `Department` varchar(50) NOT NULL,
  `Class` varchar(20) NOT NULL,
  `Subject` varchar(100) NOT NULL,
  `Teacher` varchar(50) NOT NULL,
  `Message` varchar(20) NOT NULL
) ENGINE=InnoDB DEFAULT CHARSET=utf8mb4;

-- --------------------------------------------------------

--
-- Table structure for table `questionaire`
--

CREATE TABLE `questionaire` (
  `ID` int(9) NOT NULL,
  `que1` varchar(255) NOT NULL,
  `que2` varchar(255) NOT NULL,
  `que3` varchar(255) NOT NULL,
  `que4` varchar(255) NOT NULL,
  `que5` varchar(255) NOT NULL,
  `que6` varchar(255) NOT NULL,
  `que7` varchar(255) NOT NULL,
  `que8` varchar(255) NOT NULL,
  `que9` varchar(255) NOT NULL,
  `que10` varchar(255) NOT NULL,
  `status` varchar(10) NOT NULL
) ENGINE=InnoDB DEFAULT CHARSET=utf8mb4;

--
-- Dumping data for table `questionaire`
--

INSERT INTO `questionaire` (`ID`, `que1`, `que2`, `que3`, `que4`, `que5`, `que6`, `que7`, `que8`, `que9`, `que10`, `status`) VALUES
(11, 'Did you like the teacher?', 'Does she have knowledge?', 'Is the teacher punctual?', 'Is her voice audible?', 'Does the teacher give you notes?', 'Does the teacher solve your problems?', 'Is the teacher helpful outside the class?', 'Does the teacher have practical knowledge?', 'Does she use the black board correctly?', 'Does she refer the reference book?', 'on');

-- --------------------------------------------------------

--
-- Table structure for table `staff_details`
--

CREATE TABLE `staff_details` (
  `Prn_no` int(9) NOT NULL,
  `Name` varchar(50) NOT NULL,
  `Department` varchar(50) NOT NULL,
  `Password` varchar(50) NOT NULL
) ENGINE=InnoDB DEFAULT CHARSET=utf8mb4;

--
-- Dumping data for table `staff_details`
--

INSERT INTO `staff_details` (`Prn_no`, `Name`, `Department`, `Password`) VALUES
(101, 'Abhijit A Salunkhe', 'Computer', 'Abhijit A Salunkhe7533'),
(102, 'Vandana R Nangare', 'Computer', 'Vandana R Nangare7201'),
(103, 'Priyanka S Kedge', 'Computer', 'Priyanka S Kedge1377');

-- --------------------------------------------------------

--
-- Table structure for table `student_details`
--

CREATE TABLE `student_details` (
  `ID` int(9) NOT NULL,
  `Enrollment_no` int(50) NOT NULL,
  `Roll_no` int(5) NOT NULL,
  `Student_name` varchar(100) NOT NULL,
  `Class_name` varchar(100) NOT NULL,
  `Course` varchar(20) NOT NULL,
  `Department` varchar(50) NOT NULL,
  `Password` varchar(50) NOT NULL
) ENGINE=InnoDB DEFAULT CHARSET=utf8mb4;

--
-- Dumping data for table `student_details`
--

INSERT INTO `student_details` (`ID`, `Enrollment_no`, `Roll_no`, `Student_name`, `Class_name`, `Course`, `Department`, `Password`) VALUES
(18, 1815320063, 17, 'Pratiksha Sharad Malekar', 'TYCO', 'CO-5-I', 'Computer', 'Pratiksha Sharad Malekar8245'),
(19, 1815320060, 15, 'Manasi Santosh Tungatkar', 'TYCO', 'CO-5-I', 'Computer', 'Manasi Santosh Tungatkar3195'),
(20, 1915320150, 36, 'Vaishnavi Sanjay Jagtap', 'TYCO', 'CO-5-I', 'Computer', 'Vaishnavi Sanjay jagtap 1370'),
(22, 1812835546, 19, 'Nikita Yadav', 'FYCO', 'CO-1-I', 'Computer', 'Nikita Yadav9706');

-- --------------------------------------------------------

--
-- Table structure for table `student_feedback`
--

CREATE TABLE `student_feedback` (
  `ID` int(9) NOT NULL,
  `Enrollment_no` int(50) NOT NULL,
  `Roll_no` int(5) NOT NULL,
  `Student_name` varchar(100) NOT NULL,
  `Course` varchar(20) NOT NULL,
  `Class_name` varchar(20) NOT NULL,
  `Department` varchar(50) NOT NULL,
  `Subject_code` int(20) NOT NULL,
  `Subject_name` varchar(100) NOT NULL,
  `Subject_teacher` varchar(50) NOT NULL,
  `que1` int(5) NOT NULL,
  `que2` int(5) NOT NULL,
  `que3` int(5) NOT NULL,
  `que4` int(5) NOT NULL,
  `que5` int(5) NOT NULL,
  `que6` int(5) NOT NULL,
  `que7` int(5) NOT NULL,
  `que8` int(5) NOT NULL,
  `que9` int(5) NOT NULL,
  `que10` int(5) NOT NULL,
  `Total` int(10) NOT NULL,
  `Suggestion` text DEFAULT NULL
) ENGINE=InnoDB DEFAULT CHARSET=utf8mb4;

--
-- Dumping data for table `student_feedback`
--

INSERT INTO `student_feedback` (`ID`, `Enrollment_no`, `Roll_no`, `Student_name`, `Course`, `Class_name`, `Department`, `Subject_code`, `Subject_name`, `Subject_teacher`, `que1`, `que2`, `que3`, `que4`, `que5`, `que6`, `que7`, `que8`, `que9`, `que10`, `Total`, `Suggestion`) VALUES
(12, 1815320063, 17, 'Pratiksha Sharad Malekar', 'CO-5-I', 'TYCO', 'Computer', 22519, 'CSS', 'Abhijit A Salunkhe', 5, 5, 3, 4, 5, 4, 3, 5, 4, 5, 43, 'Nice Teaching'),
(13, 1815320063, 17, 'Pratiksha Sharad Malekar', 'CO-5-I', 'TYCO', 'Computer', 22447, 'ESY', 'Sonali B Shinde', 4, 5, 4, 4, 5, 5, 4, 4, 5, 4, 44, ''),
(14, 1815320063, 17, 'Pratiksha Sharad Malekar', 'CO-5-I', 'TYCO', 'Computer', 22518, 'STE', 'Vandana R Nangare', 3, 4, 4, 3, 4, 3, 4, 3, 4, 4, 36, 'Good Performance'),
(15, 1815320063, 17, 'Pratiksha Sharad Malekar', 'CO-5-I', 'TYCO', 'Computer', 22516, 'OSY', 'Priyanka S Kedge', 3, 4, 3, 4, 3, 3, 4, 4, 4, 3, 35, 'ok'),
(16, 1815320063, 17, 'Pratiksha Sharad Malekar', 'CO-5-I', 'TYCO', 'Computer', 22517, 'AJP', 'Priyanka S Kedge', 4, 3, 4, 3, 4, 3, 4, 4, 3, 3, 35, 'better');

-- --------------------------------------------------------

--
-- Table structure for table `subject_details`
--

CREATE TABLE `subject_details` (
  `ID` int(9) NOT NULL,
  `Course` varchar(20) NOT NULL,
  `Class_name` varchar(20) NOT NULL,
  `Subject_code` varchar(20) NOT NULL,
  `Subject_name` varchar(100) NOT NULL,
  `Subject_teacher` varchar(100) NOT NULL
) ENGINE=InnoDB DEFAULT CHARSET=utf8mb4;

--
-- Dumping data for table `subject_details`
--

INSERT INTO `subject_details` (`ID`, `Course`, `Class_name`, `Subject_code`, `Subject_name`, `Subject_teacher`) VALUES
(15, 'CO-5-I', 'TYCO', '22519', 'CSS', 'Abhijit A Salunkhe'),
(16, 'CO-5-I', 'TYCO', '22447', 'ESY', 'Sonali B Shinde'),
(17, 'CO-5-I', 'TYCO', '22518', 'STE', 'Vandana R Nangare'),
(18, 'CO-5-I', 'TYCO', '22516', 'OSY', 'Priyanka S Kedge'),
(19, 'CO-5-I', 'TYCO', '22517', 'AJP', 'Priyanka S Kedge'),
(20, 'CO-1-I', 'FYCO', '22516', 'ESY', 'Abhijit A Salunkhe');

--
-- Indexes for dumped tables
--

--
-- Indexes for table `class_details`
--
ALTER TABLE `class_details`
  ADD PRIMARY KEY (`ID`),
  ADD UNIQUE KEY `Class_name` (`Class_name`,`Course`,`Department`);

--
-- Indexes for table `hod_details`
--
ALTER TABLE `hod_details`
  ADD PRIMARY KEY (`Prn_no`),
  ADD UNIQUE KEY `Name` (`Name`,`Department`,`Password`);

--
-- Indexes for table `principal_details`
--
ALTER TABLE `principal_details`
  ADD PRIMARY KEY (`ID`);

--
-- Indexes for table `principal_hod_feedback`
--
ALTER TABLE `principal_hod_feedback`
  ADD PRIMARY KEY (`ID`);

--
-- Indexes for table `questionaire`
--
ALTER TABLE `questionaire`
  ADD PRIMARY KEY (`ID`);

--
-- Indexes for table `staff_details`
--
ALTER TABLE `staff_details`
  ADD PRIMARY KEY (`Prn_no`);

--
-- Indexes for table `student_details`
--
ALTER TABLE `student_details`
  ADD PRIMARY KEY (`ID`),
  ADD UNIQUE KEY `Roll_no` (`Roll_no`,`Student_name`),
  ADD UNIQUE KEY `Enrollment_no` (`Enrollment_no`);

--
-- Indexes for table `student_feedback`
--
ALTER TABLE `student_feedback`
  ADD PRIMARY KEY (`ID`),
  ADD UNIQUE KEY `Enrollment_no` (`Enrollment_no`,`Roll_no`,`Student_name`,`Subject_code`,`Subject_name`);

--
-- Indexes for table `subject_details`
--
ALTER TABLE `subject_details`
  ADD PRIMARY KEY (`ID`),
  ADD UNIQUE KEY `Class_name` (`Class_name`,`Subject_code`,`Subject_name`);

--
-- AUTO_INCREMENT for dumped tables
--

--
-- AUTO_INCREMENT for table `class_details`
--
ALTER TABLE `class_details`
  MODIFY `ID` int(9) NOT NULL AUTO_INCREMENT, AUTO_INCREMENT=39;

--
-- AUTO_INCREMENT for table `principal_details`
--
ALTER TABLE `principal_details`
  MODIFY `ID` int(9) NOT NULL AUTO_INCREMENT, AUTO_INCREMENT=2;

--
-- AUTO_INCREMENT for table `principal_hod_feedback`
--
ALTER TABLE `principal_hod_feedback`
  MODIFY `ID` int(9) NOT NULL AUTO_INCREMENT, AUTO_INCREMENT=9;

--
-- AUTO_INCREMENT for table `questionaire`
--
ALTER TABLE `questionaire`
  MODIFY `ID` int(9) NOT NULL AUTO_INCREMENT, AUTO_INCREMENT=12;

--
-- AUTO_INCREMENT for table `student_details`
--
ALTER TABLE `student_details`
  MODIFY `ID` int(9) NOT NULL AUTO_INCREMENT, AUTO_INCREMENT=23;

--
-- AUTO_INCREMENT for table `student_feedback`
--
ALTER TABLE `student_feedback`
  MODIFY `ID` int(9) NOT NULL AUTO_INCREMENT, AUTO_INCREMENT=24;

--
-- AUTO_INCREMENT for table `subject_details`
--
ALTER TABLE `subject_details`
  MODIFY `ID` int(9) NOT NULL AUTO_INCREMENT, AUTO_INCREMENT=21;
COMMIT;

/*!40101 SET CHARACTER_SET_CLIENT=@OLD_CHARACTER_SET_CLIENT */;
/*!40101 SET CHARACTER_SET_RESULTS=@OLD_CHARACTER_SET_RESULTS */;
/*!40101 SET COLLATION_CONNECTION=@OLD_COLLATION_CONNECTION */;

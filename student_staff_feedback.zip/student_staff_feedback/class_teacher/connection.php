<?php $host ="localhost";
$username= "root";
$pwd="";
$database = "student";
global $conn;
$conn = new mysqli($host,$username,$pwd,$database);
if($conn->connect_error){  
	echo $conn->connect_error;
}
?>
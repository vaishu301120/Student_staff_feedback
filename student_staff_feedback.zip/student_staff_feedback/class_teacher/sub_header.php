<?php 
if(!isset($_SESSION['classteacher']))
{
	echo "<script>alert('Login First');
	window.location.href='classteacher_login.php';</script>";
}
else
{
	$theclassteacher = $_SESSION['classteacher'];
		
}

$sql = "SELECT Name,Department FROM staff_details WHERE Prn_no=$theclassteacher";
	$query = mysqli_query($conn,$sql) or die(mysqli_error());

	while($row = mysqli_fetch_array($query))
	{
	$sub_header_name=$row['Name'];
	$sub_header_department=$row['Department'];
	}
	
$sql = "SELECT Class_name FROM class_details WHERE Class_teacher='$sub_header_name'";
		$query = mysqli_query($conn,$sql) or die(mysqli_error());

		while($row = mysqli_fetch_array($query))
		{
		$sub_header_classname=$row['Class_name'];
		}
	

?>
<div class="container-fluid" style="background-color:#1aa5d8;min-height: 40px;">
	<div class="container">
		<div class="row" style="color: white;font-size: 16px;padding-top: 6px;">
			<div class="col-lg-3">Welcome <?php echo $sub_header_name; ?>,</div>
			<div class="col-lg-4">Designation :: Class Teacher(<?php echo $sub_header_classname; ?>)</div>
			<div class="col-lg-3">Department :: <?php echo $sub_header_department; ?></div>
			<div class="col-lg-1"><a href="logout.php" style="color:white;">Logout</a></div>
		</div>
	</div>
</div>
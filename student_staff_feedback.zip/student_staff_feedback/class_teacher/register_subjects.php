<?php include "header.php";
include "connection.php";
include "sub_header.php";

error_reporting(0);

if(!isset($_SESSION['classteacher']))
{
	echo "<script>alert('Login First');
	window.location.href='classteacher_login.php';</script>";
}
else
{
	$theclassteacher = $_SESSION['classteacher'];
		
}

$sql = "SELECT Name,Department FROM staff_details WHERE Prn_no=$theclassteacher";
	$query = mysqli_query($conn,$sql) or die(mysqli_error());

	while($row = mysqli_fetch_array($query))
	{
	$class_teacher_name=$row['Name'];
	$deparment = $row['Department'];
	}
	
	$sql = "SELECT Class_name,Course FROM class_details WHERE Class_teacher='$class_teacher_name'";
	$query = mysqli_query($conn,$sql) or die(mysqli_error());

	while($row = mysqli_fetch_array($query))
	{
	$class_name=$row['Class_name'];
	$course_name=$row['Course'];
	}
	
	
?>
<script>
	document.getElementById("subjects").onsubmit = function() { location.reload(true); } 
	
function deleteclassrecord(id){
	var confirm_status = confirm("Do you want to Delete Subject");
	if(confirm_status == true){
		xhr2 = new XMLHttpRequest();
		xhr2.open('GET','subjectdeleterecord_ajax_call.php?id=' + id , false );
		xhr2.onload = function(){
			location.reload();
		}
		xhr2.send();
	}
}

</script>

<?php if(isset($_POST['submit'])){
	//$class_name = $_POST['class_name'];
	$course_name = $_POST['course_name'];
	$subject_code = $_POST['subject_code'];
	$subject_name = $_POST['subject_name'];
	$subject_teacher = $_POST['subject_teacher'];
	
	$sql = "INSERT INTO `subject_details` (`Course`, `Class_name`, `Subject_code`, `Subject_name`, `Subject_teacher`) VALUES ('$course_name','$class_name','$subject_code', '$subject_name', '$subject_teacher');";
		$is_success = $conn->query($sql);
		if($is_success){ ?>
			<script>
			  alert("Subject Registered Successfully");
			</script>
		<?php }
		else { ?>
			<script>alert("Record Not Inserted");</script>
		<?php }
}
?>

<div class="container" style="background-color: #4444;">
	<div class="jumbotron">
		<div class="card" style="text-align: center;"><h2>Register Subjects</h2></div>
		<div style="height:50px;"></div>
		<div class="card">
			<div class="card-body">
				<form method="POST" id="subjects" style="font-size:18px;">
					Course<input type="text" name="course_name" id="course_name" value="<?php echo $course_name; ?>" class="form-control" readonly><br>
					Class Name<input type="text" name="class_name" value="<?php echo $class_name; ?>" class="form-control" readonly><br>
					<!-- Class<select name="class_name" id="class_name" class="form-control" required>
									<option>Select Class</option>
										<?php //$sql = "SELECT Class_name FROM class_details WHERE Course='$selected_course'";
											  //$query = mysqli_query($conn,$sql) or die(mysqli_error());

													//while($row = mysqli_fetch_array($query))
													{ ?>
														<option value="<?php //echo $row['Class_name']; ?>"><?php //echo $row['Class_name']; ?></option>
													<?php }
										?>
						  </select><br> -->
						  
					Subject Teacher<select name="subject_teacher" id="subject_teacher" class="form-control" required>
									<option value="">Select Staff</option>
										<?php $sql = "SELECT Name FROM staff_details WHERE Department='$deparment'";
											  $query = mysqli_query($conn,$sql) or die(mysqli_error());

													while($row = mysqli_fetch_array($query))
													{ ?>
														<option value="<?php echo $row['Name']; ?>"><?php echo $row['Name']; ?></option>
													<?php }
										?>
						  </select><br>
						  
					Subject Code<input type="text" name="subject_code" class="form-control" required><br>
					Subject Name<input type="text" name="subject_name" class="form-control" required><br>
					<input type="submit" name="submit" value="Submit">
				</form>
			</div>
		</div>
		<div style="height:50px;"></div>
		<div class="card" style="text-align: center;"><h2>Update Subject Details</h2></div>
			<div class="card">
				<div class="card-body" style="text-align:center;">
					<table class="table table-bordered">
						<tr>
							<th>Course</th>
							<th>Course Name</th>
							<th>Subject Code</th>
							<th>Subject Name</th>
							<th>Subject Teacher</th>
							<th>Action</th>
						</tr>
					 <?php $sql = "SELECT * FROM subject_details where Course='$course_name' AND Class_name='$class_name'";
						  $query = mysqli_query($conn,$sql) or die(mysqli_error());			
						  while($row = mysqli_fetch_array($query))
							{
									echo "<tr>";
									echo "<td>".$row['Course']."</td>";
									echo "<td>".$row['Class_name']."</td>";
									echo "<td>".$row['Subject_code']."</td>";
									echo "<td>".$row['Subject_name']."</td>";
									echo "<td>".$row['Subject_teacher']."</td>";
									echo "<td><a href='update_subject.php?&id=$row[ID]&course=$row[Course]&cn=$row[Class_name]&subjectcode=$row[Subject_code]&subjectname=$row[Subject_name]&subjectteacher=$row[Subject_teacher]&dept=$deparment' class='btn btn-success' style='margin-right: 16px;padding: 5px 40px;'>Edit</a><button type='button' class='btn btn-warning' onclick='deleteclassrecord(".$row['ID'].")' style='margin-right: 16px;padding: 5px 40px;'>Delete</button></td>";
									echo "</tr>";
							}
					 ?>
					</table>
	            </div>
			</div>



<?php include "footer.php" ?>
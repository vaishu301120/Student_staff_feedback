<?php 
//include "header.php";
include "connection.php";
//include "sub_header.php";

if(!isset($_SESSION['classteacher']))
{
	echo "<script>alert('Login First');
	window.location.href='classteacher_login.php';</script>";
}
else
{
	$theclassteacher = $_SESSION['classteacher'];
		
}

$ct_department = $_GET['department'];
$class = $_GET['class']; 
$subject = $_GET['subject'];

$aggregate = array();

	$sql = "SELECT Subject_teacher,Total FROM student_feedback WHERE Department='$ct_department' AND Class_name='$class' AND Subject_Name='$subject'";
	$query = mysqli_query($conn,$sql) or die(mysqli_error());

	while($row = mysqli_fetch_array($query))
	{
		$subject_teacher=$row['Subject_teacher'];
		array_push($aggregate,$row['Total']);
	}
	
	?>
	
	<table class="table table-bordered">
		<tr style='background-color:lightblue;'>
			<th>Department</th>
			<th>Class</th>
			<th>Subject</th>
			<th>Subject Teacher</th>
			<th>No. of students gave feedback</th>
			<th>Feedback Aggregate</th>
		</tr>

		<?php
		echo "<tr style='background-color:white;'>";
		echo "<td>".$ct_department."</td>";
		echo "<td>".$class."</td>";
		echo "<td>".$subject."</td>";
		echo "<td>".$subject_teacher."</td>";
		echo "<td>".count($aggregate)."</td>";
		echo "<td>".array_sum($aggregate)/count($aggregate)."</td>";
		echo "</tr>";
		?>
</table>



<?php 
include "footer.php";
?>
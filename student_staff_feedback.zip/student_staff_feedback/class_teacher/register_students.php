<?php include "header.php";
include "connection.php";
include "sub_header.php";
error_reporting(0);

if(!isset($_SESSION['classteacher']))
{
	echo "<script>alert('Login First');
	window.location.href='classteacher_login.php';</script>";
}
else
{
	$theclassteacher = $_SESSION['classteacher'];
		
}

$sql = "SELECT Name,Department FROM staff_details WHERE Prn_no=$theclassteacher";
	$query = mysqli_query($conn,$sql) or die(mysqli_error());

	while($row = mysqli_fetch_array($query))
	{
	$class_teacher_name=$row['Name'];
	$class_teacher_department = $row['Department'];
	}
	
	$sql1 = "SELECT Class_name,Course FROM class_details WHERE Class_teacher='$class_teacher_name'";
	$query1 = mysqli_query($conn,$sql1) or die(mysqli_error());

	while($row1 = mysqli_fetch_array($query1))
	{
	$class_name=$row1['Class_name'];
	$course_name=$row1['Course'];
	}


if(isset($_POST['submit'])){
	$enrollment_no = $_POST['enrollment_no'];
	$roll_no = $_POST['roll_no'];
	$student_name = $_POST['student_name'];
	$class_name = $_POST['class_name'];
	$course_name = $_POST['course_name'];
	$department = $_POST['department'];
	
	$password = $student_name.rand(0,9999);
	
	$sql = "INSERT INTO `student_details` (`Enrollment_no`, `Roll_no`, `Student_name`, `Class_name`, `Course`, `Department`, `Password`) VALUES ($enrollment_no, $roll_no, '$student_name', '$class_name','$course_name','$department', '$password');";
		$is_success = $conn->query($sql);
		if($is_success){ ?>
			<script>
			  alert("Student details Registered Successfully");
			</script>
		<?php }
		else { ?>
			<script>alert("Record Not Inserted");</script>
		<?php }
}
?>
<script>
	document.getElementById("student").onsubmit = function() { location.reload(true); } 
	
function deletestudentrecord(id){
	var confirm_status = confirm("Do you want to Delete Record");
	if(confirm_status == true){
		xhr2 = new XMLHttpRequest();
		xhr2.open('GET','studentdeleterecord_ajax_call.php?id=' + id , false );
		xhr2.onload = function(){
			location.reload();
		}
		xhr2.send();
	}
}

</script>
<div class="container" style="background-color: #4444;">
	<div class="jumbotron">
		<div class="card" style="text-align: center;"><h2>Register Student</h2></div>
		<div style="height:50px;"></div>
		<div class="card">
			<div class="card-body">
				<form method="POST" id="student" style="font-size:18px;">
					Enrollment No<input type="number" name="enrollment_no" class="form-control" required><br>
					Roll No<input type="number" name="roll_no" class="form-control" required><br>
					Name<input type="text" name="student_name" class="form-control" required><br>
					Class Name<input type="text" name="class_name" value="<?php echo $class_name; ?>" class="form-control" readonly><br>
					Course<input type="text" name="course_name" value="<?php echo $course_name; ?>" class="form-control" readonly><br>
					Department<input type="text" name="department" value="<?php echo $class_teacher_department; ?>" class="form-control" readonly><br>
					<input type="submit" name="submit" value="Submit">
				</form>
			</div>
		</div>
		<div style="height:50px;"></div>
		<div class="card" style="text-align: center;"><h2>Update Student Details</h2></div>
			<div class="card">
				<div class="card-body" style="text-align:center;">
					<table class="table table-bordered">
						<tr style="font-size: 13px;">
							<th>Enroll No</th>
							<th>Roll No</th>
							<th>Stud Name</th>
							<th>Class Name</th>
							<th>Course</th>
							<th>Dept</th>
							<th>Action</th>
						</tr>
					 <?php $sql = "SELECT * FROM student_details where Course='$course_name' and Class_name='$class_name' and Department='$class_teacher_department'";
						  $query = mysqli_query($conn,$sql) or die(mysqli_error());			
						  while($row = mysqli_fetch_array($query))
							{
									echo "<tr>";
									echo "<td>".$row['Enrollment_no']."</td>";
									echo "<td>".$row['Roll_no']."</td>";
									echo "<td>".$row['Student_name']."</td>";
									echo "<td>".$row['Class_name']."</td>";
									echo "<td>".$row['Course']."</td>";
									echo "<td>".$row['Department']."</td>";
									echo "<td><a href='update_student.php?id=$row[ID]&enroll=$row[Enrollment_no]&roll=$row[Roll_no]&name=$row[Student_name]' class='btn btn-success' style='margin-right: 16px;padding: 5px 40px;'>Edit</a><button type='button' class='btn btn-warning' onclick='deletestudentrecord(".$row['ID'].")' style='margin-right: 16px;padding: 5px 40px;'>Delete</button></td>";
									echo "</tr>";
							}
					 ?>
					</table>
	            </div>
			</div>



<?php include "footer.php" ?>
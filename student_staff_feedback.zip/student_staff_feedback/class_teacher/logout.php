<?php include "header.php";
include "connection.php";
include "sub_header.php";


session_destroy();

echo "<script>alert('Logged out successfully');
	window.location.href='/student_staff_feedback/index.php';</script>";
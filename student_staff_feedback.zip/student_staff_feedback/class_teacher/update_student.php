<?php //session_start();
include "header.php";
include "connection.php";
include "sub_header.php";

if(!isset($_SESSION['classteacher']))
{
	echo "<script>alert('Login First');
	window.location.href='classteacher_login.php';</script>";
}
else
{
	$theclassteacher = $_SESSION['classteacher'];
		
}

$id = $_GET['id'];
$enrollment = $_GET['enroll'];
$roll = $_GET['roll'];
$name = $_GET['name'];

?>
<div class="container" style="background-color: #4444;">
	<div class="jumbotron">
		<div class="card" style="text-align: center;"><h2>Edit Details for Enrollment no: <?php echo $enrollment; ?></h2></div>
		<div style="height:50px;"></div>
		<div class="card">
			<div class="card-body">
				<form method="POST" id="hod" style="font-size:18px;">
					Enrollment No<input type="number" name="update_enroll_no" value="<?php echo $enrollment; ?>" class="form-control" required><br>
					Roll No<input type="number" name="update_roll_no" value="<?php echo $roll; ?>" class="form-control" required><br>
					Student Name<input type="text" name="update_student_name" value="<?php echo $name; ?>" class="form-control" required><br>
					<input type="submit" name="update" value="Update Details">
				</form>
			</div>
		</div>
	</div>
</div>

<?php
	if(isset($_POST['update'])){
	$update_enroll_no = $_POST['update_enroll_no'];
	$update_roll_no = $_POST['update_roll_no'];
	$update_student_name = $_POST['update_student_name'];
	
	$sql1 = "UPDATE student_details SET Enrollment_no=$update_enroll_no,Roll_no=$update_roll_no,Student_name='$update_student_name' where ID=$id";
	$query1 = mysqli_query($conn,$sql1) or die(mysqli_error());
		if($query1){ ?>
			<script>
			  alert("Student details updated Successfully");
			  window.location.href='register_students.php'; 
			</script>
		<?php }
		else { ?>
			<script>
				alert("Record Not Updated");
				window.location.href='update_staff.php';
			</script>
		<?php }
}

include "footer.php"; ?>
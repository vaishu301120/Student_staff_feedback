<?php include "header.php";
include "connection.php";
include "sub_header.php";

if(!isset($_SESSION['classteacher']))
{
	echo "<script>alert('Login First');
	window.location.href='classteacher_login.php';</script>";
}
else
{
	$theclassteacher = $_SESSION['classteacher'];
		
} 

$id = $_GET['id'];
$sql = "Delete FROM subject_details WHERE ID=$id";
	$query = mysqli_query($conn,$sql) or die(mysqli_error());
	
	if($query){ ?>
			<script>
			  alert("Subject deleted Successfully");
			  window.location.href='register_subjects.php'; 
			</script>
		<?php }
		else { ?>
			<script>
				alert("Record Not Deleted");
			</script>
		<?php }

?>


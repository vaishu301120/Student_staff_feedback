<?php include "header.php";
include "connection.php";
include "sub_header.php";

if(!isset($_SESSION['classteacher']))
{
	echo "<script>alert('Login First');
	window.location.href='classteacher_login.php';</script>";
}
else
{
	$theclassteacher = $_SESSION['classteacher'];
		
} 

$id = $_GET['id'];
$sql = "Delete FROM student_details WHERE ID=$id";
	$query = mysqli_query($conn,$sql) or die(mysqli_error());
	
	if($query){ ?>
			<script>
			  alert("Student details deleted Successfully");
			  window.location.href='register_students.php'; 
			</script>
		<?php }
		else { ?>
			<script>
				alert("Record Not Deleted");
			</script>
		<?php }

?>


<?php //session_start();
include "header.php";
include "connection.php";
include "sub_header.php";

if(!isset($_SESSION['classteacher']))
{
	echo "<script>alert('Login First');
	window.location.href='classteacher_login.php';</script>";
}
else
{
	$theclassteacher = $_SESSION['classteacher'];
		
}
$id = $_GET['id'];
$course = $_GET['course'];
$class_name = $_GET['cn'];
$subjectcode = $_GET['subjectcode'];
$subjectname = $_GET['subjectname'];
$subjectteacher = $_GET['subjectteacher'];
$department = $_GET['dept'];
?>
<div class="container" style="background-color: #4444;">
	<div class="jumbotron">
		<div class="card" style="text-align: center;"><h2>Edit Details for Subject: <?php echo $subjectname; ?></h2></div>
		<div style="height:50px;"></div>
		<div class="card">
			<div class="card-body">
				<form method="POST" id="class" style="font-size:18px;">
					Course<input type="text" name="update_course_name" value="<?php echo $course; ?>" class="form-control" required><br>
					Class Name<input type="text" name="update_class_name" value="<?php echo $class_name; ?>" class="form-control" readonly><br>
					Subject Code<input type="text" name="update_subject_code" value="<?php echo $subjectcode; ?>" class="form-control" required><br>
					Subject Name<input type="text" name="update_subject_name" value="<?php echo $subjectname; ?>" class="form-control" required><br>
					Subject Teacher<select name="update_subject_teacher" id="subject_teacher" class="form-control" required>
									<option value="<?php echo $subjectteacher; ?>"><?php echo $subjectteacher; ?></option>
										<?php $sql = "SELECT * FROM staff_details where Department = '$department' and Name != '$subjectteacher'";
											  $query = mysqli_query($conn,$sql) or die(mysqli_error());
													while($row = mysqli_fetch_array($query)){ ?>
															<option value="<?php echo $row['Name'] ?>"><?php echo $row['Name'] ?></option>
										<?php } ?>
								</select><br>
					<input type="submit" name="update" value="Update Details">
				</form>
			</div>
		</div>
	</div>
</div>

<?php
	if(isset($_POST['update'])){
	$update_course_name = $_POST['update_course_name'];
	$update_subject_code = $_POST['update_subject_code'];
	$update_subject_name = $_POST['update_subject_name'];
	$update_subject_teacher = $_POST['update_subject_teacher'];
	
	$sql1 = "UPDATE subject_details SET Course='$update_course_name',Subject_code='$update_subject_code',Subject_name='$update_subject_name',Subject_teacher='$update_subject_teacher' where ID=$id";
	$query1 = mysqli_query($conn,$sql1) or die(mysqli_error());
		if($query1){ ?>
			<script>
			  alert("Subject updated Successfully");
			  window.location.href='register_subjects.php'; 
			</script>
		<?php }
		else { ?>
			<script>
				alert("Record Not Updated");
				window.location.href='update_subject.php';
			</script>
		<?php }
}

include "footer.php"; ?>
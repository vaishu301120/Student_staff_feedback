<?php include "header.php";
include "connection.php";
include "sub_header.php";

if(!isset($_SESSION['classteacher']))
{
	echo "<script>alert('Login First');
	window.location.href='classteacher_login.php';</script>";
}
else
{
	$theclassteacher = $_SESSION['classteacher'];
		
}

$sql = "SELECT Name,Department FROM staff_details WHERE Prn_no=$theclassteacher";
	$query = mysqli_query($conn,$sql) or die(mysqli_error());

	while($row = mysqli_fetch_array($query))
	{
	$class_teacher_name=$row['Name'];
	$class_teacher_dept=$row['Department'];
	}
	
$sql = "SELECT Class_name FROM class_details WHERE Class_teacher='$class_teacher_name'";
	$query = mysqli_query($conn,$sql) or die(mysqli_error());

	while($row = mysqli_fetch_array($query))
	{
	$class_teacher_classname=$row['Class_name'];	
	}
	
?>

<div class="container" style="background-color: #4444;">
	<div class="jumbotron">
		<div class="card" style="text-align: center;"><h2>Class Wise Feedback</h2></div>
		<div style="height:50px;"></div>
		<div class="card">
			<div class="card-body">
				<form method="POST" id="staff" style="font-size:18px;">
					Department<input type="text" name="dept" id="dept" class="alternate-form-control" style="background-color: #e9ecef;opacity: 1;" value="<?php echo $class_teacher_dept; ?>" readonly>
					Class Name<input type="text" name="classname" id="classname" class="alternate-form-control" style="background-color: #e9ecef;opacity: 1;" value="<?php echo $class_teacher_classname; ?>" readonly>
					Select Subject<select id="subject" class="alternate-form-control" onchange="myFunctionsss()">
						<option selected>Select subject</option>
							<?php $sql = "SELECT Subject_name FROM subject_details where Class_name = '$class_teacher_classname'";
								  $query = mysqli_query($conn,$sql) or die(mysqli_error());
									while($row = mysqli_fetch_array($query))
										{ ?>
											<option value="<?php echo $row['Subject_name']; ?>"><?php echo $row['Subject_name']; ?></option>	
										<?php } ?>
										</select>
										
				</form>
			</div>
		</div>
		<div style="height:50px;"></div>
		<div class="card" style="text-align: center;"><h2>View Report</h2></div>
			<div class="card">
				<div class="card-body" id="outputsss" style="text-align:center;">
					<!-- output table will appear here -->
	            </div>
			</div>
<script>

function myFunctionsss(){
	//document.getElementById('output').innerHTML = '';
	var dept = document.getElementById("dept").value;
	var options_selected = document.getElementById("classname").value;
	var optionss_selected = document.getElementById("subject").value;
	xhrsss = new XMLHttpRequest();
	xhrsss.open('GET','attend_ct_view_report_aggregate.php?department=' + dept + '&class=' + options_selected + '&subject=' + optionss_selected );
	xhrsss.onload = function(){
		document.getElementById('outputsss').innerHTML = xhrsss.responseText;
	}
	xhrsss.send();
}
</script>

<style>
.alternate-form-control{
	padding: .375rem .75rem;
    font-size: 1rem;
	color: #495057;
	border: 1px solid #ced4da;
	border-radius: .25rem;
	transition: border-color .15s ease-in-out,box-shadow .15s ease-in-out;
	margin: 0 30px 0 10px;
}
</style>
<?php include "footer.php" ?>